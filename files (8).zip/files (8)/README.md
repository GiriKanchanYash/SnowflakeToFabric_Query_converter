# Git Repository Clone + Snowflake → Fabric SQL Conversion (no frameworks)

Plain HTML/CSS/JS frontend + a Python backend built only on the standard
library (`http.server`, `subprocess`, `threading`, `json`, `urllib`). No
Flask, no GitPython, no `openai` package — just Python 3, Git, and an
Azure OpenAI resource.

## Set up your Azure OpenAI credentials

Pick **one**:

**Option A — environment variables**
```bash
export AZURE_OPENAI_ENDPOINT="https://YOUR-RESOURCE-NAME.openai.azure.com"
export AZURE_OPENAI_API_KEY="your-api-key"
export AZURE_OPENAI_DEPLOYMENT="your-deployment-name"
export AZURE_OPENAI_API_VERSION="2024-08-01-preview"   # optional, this is the default
```

**Option B — local config file**
```bash
cp azure_openai_config.example.json azure_openai_config.json
# then edit azure_openai_config.json with your real values
```
This file is in `.gitignore` — it will not be committed. Environment
variables take a back seat to this file if both are present.

## Run it

```bash
python server.py
```

Open http://localhost:5000. No `pip install` needed for either step.

## Files

- `server.py` — the HTTP server. `http.server.ThreadingHTTPServer` serves
  the static files and a small JSON API for clone, extract, convert
  (stage), and review (approve/reject).
- `extractor.py` — splits `.sql` files into one file per SQL object,
  classified into a medallion layer.
- `converter.py` — sends each object to Azure OpenAI and returns a
  PySpark notebook-cell snippet; orchestrates staging, approval, and
  rejection.
- `schema_mapper.py` — rewrites Snowflake schema names to the Fabric
  Lakehouse's existing schemas, enforced deterministically (not just
  requested via the prompt).
- `notebook_builder.py` — builds/appends to the per-layer `.ipynb` files.
- `azure_openai_client.py` — a small stdlib-only REST client for Azure
  OpenAI's chat completions endpoint (retries on 429/5xx, clear errors on
  401/403/404).
- `azure_openai_config.example.json`, `layer_mapping.json`,
  `lakehouse_config.json`, `schema_mapping.json` — editable config, no
  code changes needed to adjust any of them.
- `index.html`, `style.css`, `script.js` — the UI (3 tabs: Clone, Review &
  convert, Code review). All files must sit in the same folder.

## How it works

### Step 1 — Clone
Same as before: `POST /api/clone` with `repo_url`, `branch`, `local_path`;
conflicts on an existing directory are resolved with `on_exists`
(`pull`/`overwrite`/`cancel`); progress is polled from
`GET /api/clone/status/<job_id>`.

### Step 2 — Extract (new: object-level, no API calls, grouped by medallion layer)
Once a clone succeeds, the UI reveals an "Extract SQL objects" step.
`POST /api/extract` with:
```json
{ "local_path": "/path/to/cloned/repo", "output_path": "/path/to/repo_fabric" }
```
`output_path` defaults to `<local_path>_fabric` if omitted. **This step
never touches Azure OpenAI and never requires credentials to be
configured** — it only splits files. Sending an entire `.sql` file to the
API doesn't scale (some files hold dozens of objects and blow past the
token limit), so every `.sql` file is first split into one file per
top-level SQL object (table, view, procedure, function, dynamic table, or
standalone statement) using a small tokenizer that tracks string
literals, quoted identifiers, `$$...$$` procedure bodies, and comments —
not a naive split on `;`, which would break inside a Snowflake procedure
body.

Each object is also classified into a **medallion layer** — `bronze`,
`silver`, `gold`, or `unclassified` — and written to:
```
output_path/extracted/<layer>/<source file name>/<OBJECT_NAME>.sql
```
Classification (`extractor.infer_layer()`) tries, in order:
1. An exact schema match against `layer_mapping.json` (ships pre-filled
   for this project's schemas: `SAP_STG` → bronze, `RAW_VAULT` → silver,
   `INFORMATION_MART` → gold — edit this file if your schemas differ).
2. A keyword guess against the schema name (`STG`/`RAW`/`STAGE` → bronze,
   `VAULT` → silver, `MART` → gold).
3. The same keyword guess against the source filename, for objects with
   no schema-qualified name.
4. `unclassified`, if nothing matched — surfaced plainly rather than
   silently guessed wrong, so you can add a mapping entry instead of
   quietly losing track of an object.

Filenames follow the object's qualified name with dots turned into
underscores (e.g. `CLEAR_TO_BUILD_DEV.INFORMATION_MART.SP_X` →
`CLEAR_TO_BUILD_DEV_INFORMATION_MART_SP_X.sql`); duplicate names within
the same layer+source-file folder get a `_2`, `_3`, ... suffix. A
`manifest.json` is written to `output_path` with one entry per object
(every entry starts `"status": "pending"`), giving full traceability back
to its source file, layer, and exact statement position:
```json
{
  "source_file": "information_mart_procs (1).sql",
  "sequence": 3,
  "object_type": "PROCEDURE",
  "object_name": "CLEAR_TO_BUILD_DEV.INFORMATION_MART.SP_REFRESH_CTB_DATA",
  "layer": "gold",
  "filename": "CLEAR_TO_BUILD_DEV_INFORMATION_MART_SP_REFRESH_CTB_DATA.sql",
  "extracted_path": ".../extracted/gold/information_mart_procs_1/CLEAR_TO_BUILD_DEV_INFORMATION_MART_SP_REFRESH_CTB_DATA.sql",
  "relative_path": "gold/information_mart_procs_1/CLEAR_TO_BUILD_DEV_INFORMATION_MART_SP_REFRESH_CTB_DATA.sql",
  "line_start": 227, "line_end": 284,
  "status": "pending", "converted_path": null, "error": null
}
```
Extraction success automatically unlocks and switches to the **Review &
convert** tab.

> Note: grouping by layer replaces the earlier "mirror the source repo's
> folder structure" layout. A nested source repo's own subdirectories are
> no longer reflected in the output tree, though the original path is
> still recorded in each entry's `source_file` field for traceability.
> This was a deliberate tradeoff to make layer the primary grouping.

### Step 3 — Review (new)
The Review tab lists every extracted object with its layer, type, source
file, and status. From here you can:
- **Filter by medallion layer** using the Bronze / Silver / Gold /
  Unclassified chips (with live counts), to work through one layer at a
  time.
- **Search/filter** by object name, filename, source file, object type,
  or layer (client-side, instant, and combines with the layer chip).
- **Click any object** to load its extracted SQL into an inline editor
  (`GET /api/file?path=...`).
- **Edit and save** the SQL before conversion (`POST /api/file`) — the
  saved content is exactly what gets sent to Azure OpenAI later, so you
  can fix something the extractor got slightly wrong, or trim a huge
  object, before spending an API call on it.
- **Select** individual objects via checkboxes, or "Select all visible"
  to select everything currently matching the search + layer filter —
  e.g. filter to Gold, select all, convert just that layer.

**No SQL is sent to Azure OpenAI until you explicitly click "Convert
selected" or "Convert all."** Loading the tab, searching, opening a file,
or editing it never triggers an API call.

Both `GET` and `POST /api/file` are restricted to paths under a
directory that a completed `/api/extract` call actually produced
(tracked server-side in `ALLOWED_FILE_ROOTS`) — the endpoint can't be
used to read or write arbitrary files on the machine.

### Step 4 — Convert (now: stage for review, not save)
`POST /api/convert` with either:
```json
{ "manifest_path": "...", "converted_root": "...", "selected": ["relative/path/a.sql", "relative/path/b.sql"] }
```
or:
```json
{ "manifest_path": "...", "converted_root": "...", "convert_all": true }
```
The server loads `manifest.json` and sends only the requested entries to
Azure OpenAI (one request per object, using the file's *current*
content, including any edits saved during Review) — **but the result is
staged, not saved.** Nothing lands in `output_path/converted/` or a
notebook yet; the AI's output is written to `output_path/review/`
instead, and each entry's status becomes `"pending_review"`. Entries not
included in this round keep whatever status they already had (typically
still `"pending"`), so you can convert in batches.

Progress is polled from `GET /api/convert/status/<job_id>` — same job
store, same shape as clone/extract, now reporting "Converting object _N_
of _M_ for review". A failure converting one object (rate limit, bad
response, etc.) does not stop the run; it's recorded on that object's
manifest entry and the rest continue. On success, the UI unlocks and
offers to jump to the **Code review** tab.

### Step 5 — Code Review (new): compare, edit, approve or reject
Nothing from Step 4 is permanent yet. The Code Review tab lists every
`"pending_review"` object as a queue. Clicking one loads a side-by-side
comparison:
- **Left pane** — the original Snowflake SQL, read-only (`GET /api/file`
  on `extracted_path`).
- **Right pane** — the AI-converted PySpark, editable (`GET /api/file` on
  `review_path`; edits stay local to the textarea until you act on it).

From there:
- **Approve** (`POST /api/review/approve`) — writes whatever is currently
  in the right-hand textarea (your edits included, if you made any) to
  `output_path/converted/...py`, appends its notebook cell, and sets
  status to `"converted"`. This is the *only* path anything takes into
  `converted/` or a notebook.
- **Reject** (`POST /api/review/reject`, with an optional reason) — sets
  status to `"rejected"`. Nothing is written to `converted/` or a
  notebook. The staged file under `review/` is left in place for
  reference, but is never promoted.

Both endpoints are synchronous (no job/polling needed — no Azure OpenAI
call happens at approve/reject time, just file writes) and return the
updated manifest entry directly. After acting on one object, the queue
auto-advances to the next `pending_review` item.

```
output_path/
├── extracted/...          # original Snowflake SQL, one object per file
├── review/...             # AI output awaiting human approval (mirrors extracted/'s layout)
├── converted/...          # ONLY objects that were explicitly approved land here
├── notebooks/...          # ONLY approved objects' cells appear here
└── manifest.json
```

## Customizing the bronze/silver/gold mapping

Edit `layer_mapping.json` (schema name → layer, case-insensitive):
```json
{
  "SAP_STG": "bronze",
  "RAW_VAULT": "silver",
  "INFORMATION_MART": "gold"
}
```
Any schema not listed falls back to a keyword guess (see
`extractor.DEFAULT_LAYER_KEYWORDS`), and if that also finds nothing, the
object is grouped under `unclassified` rather than silently misfiled — a
visible signal to add a mapping entry for that schema.

Edit `lakehouse_config.json` to change which Lakehouse the generated
notebooks target:
```json
{ "lakehouse_name": "ReadyToBuild_Miniature" }
```

## Schema-name mapping (Snowflake schema → existing Fabric Lakehouse schema)

This Lakehouse already has its own schemas (`raw_vault`, `business_vault`,
`information_mart` — see the actual Lakehouse Explorer structure this was
built against), separate from the layer/notebook grouping above. Every
generated PySpark/Spark SQL reference gets its schema portion rewritten
to match. Edit `schema_mapping.json`:
```json
{
  "STG": "raw_vault",
  "VAULT": "business_vault",
  "MART": "information_mart"
}
```
Matched case-insensitively, exact match first then keyword/substring
(so `SAP_STG` matches the `STG` entry, `RAW_VAULT` matches `VAULT`, etc.
— same two-tier style as the layer mapping above).

This is enforced two ways, not just requested once: the prompt tells the
model to use the mapped names itself, **and** `schema_mapper.py`
deterministically rewrites any original Snowflake schema name still
present in the model's response — computed once, repo-wide, from every
extracted object (not per-object), so a schema mentioned only in a plain
status string or a `USE SCHEMA ...;` statement still gets corrected, not
just genuine dotted table references. Verified against the real repo with
a model stub that deliberately ignores the mapping instruction entirely:
zero original schema names remained anywhere in the 104 converted files'
executable code afterward. The one deliberate exception is a
`# original name: ...` traceability comment (added per the prompt), which
keeps the true original name for debugging.

## Calling the pipeline from other code

```python
from converter import extract_only, convert_objects, convert_objects_for_review, approve_object, reject_object, convert_repository

# Extraction alone -- no Azure config needed
extraction = extract_only("/path/to/cloned/repo", "/path/to/repo_fabric")
print(extraction["total"], "objects extracted, all marked pending")

# Stage a subset for review (nothing saved to converted/ or a notebook yet)
gold_only = [m for m in extraction["manifest"] if m["layer"] == "gold"]
staged = converter.convert_objects_for_review(gold_only, os.path.join("/path/to/repo_fabric", "review"),
                                               full_manifest=extraction["manifest"])

# Approve one after reviewing/editing it
entry = staged["files"][0]
with open(entry["review_path"]) as f:
    final_code = f.read()  # or your edited version
approve_object(entry, final_code, extraction["converted_root"],
               os.path.join("/path/to/repo_fabric", "notebooks"))

# Or reject it -- nothing gets written to converted/ or a notebook
# reject_object(entry, reason="needs manual rewrite")

# Or, for one-shot non-interactive use with no review step at all:
summary = convert_repository("/path/to/cloned/repo", "/path/to/repo_fabric")
```

`config` can be passed explicitly to `extract_only()`'s siblings instead
of relying on `azure_openai_client.get_config()`, if you want to supply
credentials some other way (e.g. from a secrets manager).

## Conversion rules encoded in the prompt

For table/view/dynamic-table objects (translated to Spark SQL, wrapped in
`spark.sql("""...""")`):
- `CREATE OR REPLACE TABLE x (...)` → same statement + `USING DELTA` (Delta Lake supports `CREATE OR REPLACE TABLE` natively)
- `VARCHAR(n)` → `STRING`
- `NUMBER(p,s)` → `DECIMAL(p,s)`
- `BOOLEAN` → `BOOLEAN` (unchanged)
- `TIMESTAMP_NTZ(n)` / `TIMESTAMP` / `TIMESTAMP_TZ` → `TIMESTAMP`
- `BINARY(n)` → `BINARY`
- `VARIANT` / `OBJECT` / `ARRAY` → `STRING` (JSON text) with a comment flagging the semi-structured data
- `DEFAULT CURRENT_TIMESTAMP()` → `DEFAULT current_timestamp()`, with a comment about the Delta table property it requires
- `DYNAMIC TABLE` → one-time `CREATE OR REPLACE TABLE ... AS SELECT`, with a comment that refresh needs external scheduling
- Multi-part names (`database.schema.table`) → `schema.table`, with a `# original name: ...` comment

For procedures/functions (translated to a real Python function, not SQL text):
- `DECLARE` → Python variable initialization
- `:bind_variable` → Python variable/parameter
- `SELECT ... INTO var` → `spark.sql(...).collect()` / `.first()`, unpacked into the Python variable
- `INSERT`/`UPDATE`/`DELETE`/`MERGE INTO` → `spark.sql(...)` calls, same type mapping as above
- `IF` / `EXCEPTION WHEN OTHER` / `RETURN` → native Python `if` / `try-except` / `return`
- `OBJECT_CONSTRUCT(...)` → a Python dict literal
- `MD5(...)` → Spark SQL's built-in `md5()` inside the translated SQL expression (kept set-based, not moved into row-by-row Python)

This is a best-effort, prompt-driven conversion — **review generated code
before running it against a real Lakehouse**, especially for anything
with no clean Spark/Delta equivalent (cursors, `EXECUTE IMMEDIATE`,
tasks/streams) — the prompt asks the model to flag these with a
`# NOTE:` comment rather than guess silently, but that's not a substitute
for a human review pass.

## Error handling covered

Everything from the clone step, plus: missing/misconfigured Azure OpenAI
credentials (caught before any file is sent), a `local_path` that isn't a
real directory, an unwritable `output_path`, Azure OpenAI auth failures
(401/403), wrong deployment/endpoint (404), rate limits and transient
server errors (retried with backoff, then reported), and per-object read/
write errors — all surfaced with clear messages, none of them crash the
server or abandon the rest of the batch.

## Known limitation: objects that are individually huge

Splitting stops at the SQL-object boundary, per the brief — it doesn't
split *inside* an object. One file in real-world testing contained a
single ~1,600-line stored procedure (bulk `INSERT ... VALUES` statements)
that alone runs to roughly 20K tokens. That's fine for large-context
models (GPT-4o class) but will still exceed the limit on a small-context
deployment (e.g. a 4K/8K-context GPT-3.5 deployment). If you hit this,
options include: deploying a larger-context model, or extending
`extractor.py` to further chunk a single object's literal `VALUES` rows
(not implemented here, since the brief's requested granularity is the SQL
object itself).

## Fabric notebook generation

A PySpark cell is appended to an object's medallion-layer notebook when
(and only when) it's **approved** in Code Review — `approve_object()`
writes the converted file and calls `append_object_to_notebook()` in the
same step. (`convert_objects()`, the older direct-write function kept for
non-interactive use, still does both together in one call, with no
review gate — see "Calling the pipeline from other code" above.) Each
manifest entry gains a `notebook_path` field once its cell is appended.

```
output_path/
├── extracted/...
├── converted/...
├── notebooks/
│   ├── Bronze_ReadyToBuild_Notebook.ipynb
│   ├── Silver_ReadyToBuild_Notebook.ipynb
│   └── Gold_ReadyToBuild_Notebook.ipynb
└── manifest.json
```

- One notebook per layer, named exactly as specified: `Bronze_/Silver_/
  Gold_ReadyToBuild_Notebook.ipynb`. `unclassified`-layer objects have no
  notebook mapping and are skipped (nothing named for them in the brief).
- **Cells only ever get appended, never rewritten.** Converting 5 objects
  today and 3 more next week produces a notebook with all 8 cells, in the
  order they were converted — verified by running two separate
  `convert_objects()` calls back to back and diffing the first 6 cells
  byte-for-byte before and after the second call.
- The notebook JSON's `metadata` block is copied verbatim from the
  reference notebook (`kernelspec: synapse_pyspark`, `nbformat: 4`,
  `nbformat_minor: 5`, etc.) so it opens in Fabric exactly like a notebook
  created there natively. Independently checked with the `nbformat`
  library's own validator, not just visual inspection.
- Target Lakehouse name comes from `lakehouse_config.json` (ships set to
  `ReadyToBuild_Miniature`), not hardcoded.
- Turn it off with `convert_objects(..., generate_notebooks=False)` if you
  ever want the pre-notebook behavior back exactly — confirmed by test to
  produce identical output to before this feature existed (no
  `notebook_path` key, no `notebooks/` folder at all).

### An important gap this version fixes

Earlier, the conversion prompt targeted Fabric **Warehouse** T-SQL, but
the notebook cells run in a Fabric **Lakehouse** notebook, which executes
**Spark SQL** (Delta Lake) -- a different dialect, with no stored
procedure syntax at all. That mismatch meant a generated cell often
wouldn't run without a manual edit first.

The prompt now targets the Lakehouse directly:
- Table/view/dynamic-table objects are translated straight to Spark SQL
  and wrapped in `spark.sql("""...""")` -- type mapping now goes to
  `STRING`/`DECIMAL`/`TIMESTAMP`/`BINARY` (Spark SQL types), not
  `VARCHAR`/`DATETIME2`/`VARBINARY` (T-SQL types). Delta Lake actually
  supports `CREATE OR REPLACE TABLE` natively, so this mapping is closer
  to Snowflake's own syntax than T-SQL ever was.
- Snowflake **procedures and functions**, which have no Spark SQL
  equivalent, are translated into real Python functions (`def ...`) with
  native Python control flow -- not SQL text stuffed into a string that
  would never execute as a stored procedure. Their embedded SQL
  statements (INSERT/UPDATE/MERGE/SELECT) still go through
  `spark.sql(...)`, translated with the same type-mapping rules.
- A Snowflake `DYNAMIC TABLE`, which has no direct Lakehouse equivalent,
  becomes a one-time `CREATE OR REPLACE TABLE ... AS SELECT` with a
  comment noting that periodic refresh needs to be scheduled separately.
- The model is instructed to add a `# NOTE:` comment above anything it
  isn't confident about, rather than silently guessing on constructs with
  no clean equivalent (cursors, `EXECUTE IMMEDIATE`, tasks/streams).
- A safety net (`converter._ensure_pyspark_cell()`) catches the case where
  a model response ignores the prompt and returns bare SQL with no
  `spark.sql(...)` call or Python at all -- and wraps it, so a
  non-compliant response still becomes a runnable cell instead of a
  syntax error. Confirmed by test to leave already-compliant PySpark
  responses (including full procedure functions) untouched.

**Converted output files are now `.py`, not `.sql`** — the conversion
step's output is genuinely a Python snippet now, not translated SQL text,
so the extension changed to match (`extracted/` stays `.sql`; only
`converted/` changed). Verified end-to-end against all 104 real objects
in the reference repo: every converted `.py` file, and every resulting
notebook cell, parses as valid Python (`ast.parse()`), and all three
generated notebooks pass the official `nbformat` library's validator.

None of this changed `converter.py`'s function signatures, the job/
progress-polling pattern, the manifest shape, or the API contract --
only `SYSTEM_PROMPT`'s content, the fence-stripping regex (now also
matches ` ```python ` fences), the converted-file extension, and
`notebook_builder.generate_cell_source()` (which no longer re-wraps
output that's already a complete PySpark snippet).

## Notes

- Only public repositories are supported for the clone step, per the
  original brief.
- `/api/file` (used by the Review editor) only ever reads or writes paths
  under a directory that this server itself produced via `/api/extract`
  in the current process — it's not a general file server. Restart the
  server and those roots are forgotten.
- The dev server (`http.server`) is fine for local/internal tooling like
  this. If this ever needs to run beyond localhost, put a reverse proxy
  and authentication in front of it — and never expose
  `azure_openai_config.json` or the API key through it.
