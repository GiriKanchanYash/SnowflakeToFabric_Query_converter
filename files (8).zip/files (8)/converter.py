"""
Snowflake -> Microsoft Fabric Lakehouse (PySpark / Spark SQL, Delta Lake) conversion pipeline.

Each .sql file in the repo is first split into individual top-level SQL
objects (tables, views, procedures, functions, standalone statements --
see extractor.py) so that every Azure OpenAI request carries exactly one
object, never a whole multi-statement file. This is what keeps large
files from blowing past the model's token limit.

The model is asked to return a complete, directly-runnable Fabric
notebook cell -- not just translated SQL text -- because the earlier
version of this prompt targeted Fabric *Warehouse* T-SQL, which is not
the dialect a Lakehouse notebook actually runs (Lakehouse notebooks run
Spark SQL / Delta Lake, and have no stored-procedure syntax at all, so a
Snowflake procedure has to become a real Python function, not translated
SQL wrapped in a string). notebook_builder.py uses this function's output
as the cell body verbatim.
"""

import os
import re

from azure_openai_client import AzureOpenAIError, chat_completion, get_config
from extractor import extract_sql_objects, find_sql_files, write_manifest
from notebook_builder import append_object_to_notebook, load_lakehouse_name
from schema_mapper import apply_schema_replacements, compute_global_schema_replacements, format_mapping_rules, load_schema_mapping, resolve_schema_replacements

SYSTEM_PROMPT_TEMPLATE = """You are an expert data engineer converting Snowflake SQL objects into PySpark code for a Microsoft Fabric Lakehouse notebook (Spark SQL / Delta Lake) -- one notebook cell per object.

Your entire response is the Python source of ONE notebook cell: complete, syntactically valid Python, ready to paste into a Fabric notebook and run once it is attached to the target Lakehouse. Output ONLY that Python code -- no explanations outside it, no markdown code fences.

GENERAL RULES
- Add a short "# NOTE:" comment directly above any line you are not fully confident is correct, rather than silently guessing -- especially for Snowflake Scripting constructs with no exact Spark/Delta equivalent (cursors, EXECUTE IMMEDIATE, tasks/streams, semi-structured VARIANT logic, dynamic tables).
- Preserve the object's original column names, order, and business logic. Do not invent columns, tables, or constraints that were not in the source.
- Fabric Lakehouses do not have a separate database level the way Snowflake does. Keep multi-part object names as schema.table (the last two parts only, dropping the leading database), and add a "# original name: <full original name>" comment for traceability.
- This Fabric Lakehouse already has its own schemas, different from the Snowflake originals. Replace the schema portion of EVERY table/view reference according to this mapping (case-insensitive, matched by keyword contained in the original schema name):
{schema_mapping_rules}
  Apply this to every executable reference (spark.sql strings, DataFrame/table names) in the cell -- never leave an original Snowflake schema name in code that actually runs. You may still mention the true original qualified name in a "# original name: ..." comment for traceability -- that comment is documentation, not executable code, so it should keep the real original name.

IF THE OBJECT IS A TABLE, VIEW, OR DYNAMIC TABLE (its only job is to define or populate a Delta table)
- Emit the translated statement as a Spark SQL string executed via:
      spark.sql(\"\"\"
      <translated SQL>
      \"\"\")
- "CREATE OR REPLACE TABLE x (...)" translates almost directly -- Delta Lake supports CREATE OR REPLACE TABLE natively. Add a "USING DELTA" clause and translate column types (below).
- A Snowflake DYNAMIC TABLE has no direct Lakehouse equivalent (no built-in incremental auto-refresh). Convert its defining query into "CREATE OR REPLACE TABLE x USING DELTA AS SELECT ..." (a one-time materialization), and add a comment that periodic refresh needs to be scheduled separately (e.g. a Fabric pipeline re-running this cell on a timer).
- "ALTER DYNAMIC TABLE x REFRESH" translates to re-running that table's CREATE OR REPLACE TABLE ... AS SELECT statement -- say so in a comment.
- Data type mapping (Snowflake -> Spark SQL / Delta):
      VARCHAR(n)                                    -> STRING
      NUMBER(p,s)                                   -> DECIMAL(p,s)
      BOOLEAN                                       -> BOOLEAN (unchanged)
      DATE                                          -> DATE (unchanged)
      TIMESTAMP_NTZ(n) / TIMESTAMP / TIMESTAMP_TZ   -> TIMESTAMP
      BINARY(n)                                     -> BINARY
      VARIANT / OBJECT / ARRAY                      -> STRING (store as JSON text), with a comment
          noting the column held semi-structured data in Snowflake; use ARRAY<...>/MAP<...> only if
          the element type is unambiguous from context
- "DEFAULT CURRENT_TIMESTAMP()" -> "DEFAULT current_timestamp()", with a comment that Delta column
  defaults require the table property 'delta.feature.allowColumnDefaults' = 'supported', and that
  setting the value explicitly at write time is a safe fallback if the cell errors on this.

IF THE OBJECT IS A PROCEDURE OR FUNCTION (Snowflake Scripting or SQL)
- Translate into a plain Python function (def <name_lowercased>(...):) implementing the same logic --
  Spark SQL has no stored-procedure syntax, so this cannot become translated SQL text.
- DECLARE ... -> ordinary Python variable initialization.
- Bind variables (:var_name) -> the corresponding Python variable or function parameter.
- "SELECT ... INTO var" -> run the query with spark.sql(\"\"\"...\"\"\").collect() (or .first()) and
  unpack the result into the Python variable(s).
- INSERT / UPDATE / DELETE / MERGE INTO -> spark.sql(\"\"\"<translated statement>\"\"\") calls, applying
  the same type/name-mapping rules as above.
- IF / EXCEPTION WHEN OTHER / RETURN -> native Python if / try-except / return.
- OBJECT_CONSTRUCT(...) -> a Python dict literal.
- MD5(...) / MD5_BINARY(...) -> keep the hash inside the translated SQL expression using Spark SQL's
  built-in md5() wherever the original computed it as part of a SELECT/INSERT (don't move it into
  row-by-row Python); only compute a hash in pure Python (e.g. via hashlib) if the original value was
  used purely as a Python-side variable outside any SQL statement.
- Preserve the procedure's overall control flow and error-handling intent even where exact syntax must change.
"""


def build_system_prompt():
    """
    Rebuilt on every call (cheap: a small JSON read + string format) so
    editing schema_mapping.json changes what the model is told without a
    code change or restart.
    """
    return SYSTEM_PROMPT_TEMPLATE.format(schema_mapping_rules=format_mapping_rules())


def strip_code_fences(text):
    """Model responses sometimes wrap code in ```python or ```sql fences; unwrap if present."""
    text = text.strip()
    match = re.match(r"^```(?:python|sql)?\s*\n(.*)\n```$", text, re.DOTALL)
    if match:
        return match.group(1).strip()
    return text


_BARE_SQL_LEADING_KEYWORDS_RE = re.compile(
    r"^\s*(CREATE|ALTER|INSERT|UPDATE|DELETE|MERGE|SELECT|DROP|GRANT|WITH)\b", re.IGNORECASE
)


def _ensure_pyspark_cell(text):
    """
    Safety net: the prompt asks for a complete PySpark snippet, but a model
    can still occasionally ignore that and return bare SQL text instead
    (no spark.sql(...) call, no Python at all). If that SQL-shaped-but-not-
    Python text made it straight into a notebook cell, the cell would be a
    syntax error the moment it's run. Detect that specific case and wrap it
    defensively; leave anything that already looks like Python alone.
    """
    stripped = text.strip()
    looks_like_bare_sql = (
        _BARE_SQL_LEADING_KEYWORDS_RE.match(stripped)
        and "spark.sql" not in stripped
        and "def " not in stripped
    )
    if looks_like_bare_sql:
        return f'spark.sql("""\n{stripped}\n""")\n'
    return text


def convert_sql_text(sql_code, relative_filename, config, schema_replacements=None):
    """
    Send one SQL object's contents to Azure OpenAI and return a complete
    PySpark notebook-cell snippet (not raw translated SQL -- see
    SYSTEM_PROMPT_TEMPLATE for why). notebook_builder.py uses this return
    value as the cell body verbatim; nothing wraps it further.

    schema_replacements should normally be the repo-wide dict from
    compute_global_schema_replacements() (passed in by convert_objects*),
    not rediscovered from just this one object's text -- a repo-wide dict
    also catches a schema mentioned in a plain status string or a
    "USE SCHEMA ...;" statement, which a per-object rediscovery would
    miss. Falls back to a per-object discovery only if the caller didn't
    supply one (e.g. calling this function directly, standalone).
    """
    if schema_replacements is None:
        schema_replacements = resolve_schema_replacements(sql_code)

    messages = [
        {"role": "system", "content": build_system_prompt()},
        {"role": "user", "content": (
            f"Convert the following Snowflake SQL object from '{relative_filename}' "
            f"into one Fabric Lakehouse notebook cell (PySpark / Spark SQL):\n\n{sql_code}"
        )},
    ]
    raw = chat_completion(messages, config)
    result = _ensure_pyspark_cell(strip_code_fences(raw))
    return apply_schema_replacements(result, schema_replacements)


def _report(progress_cb, **kwargs):
    if progress_cb:
        progress_cb(**kwargs)


def extract_only(local_path, output_path, progress_cb=None):
    """
    Extraction step alone -- no Azure OpenAI call, no config required.
    Splits every .sql file under local_path into one file per SQL object
    and writes manifest.json to output_path, with every entry marked
    "pending" so the Review step has something to select from before any
    API request is made.

    Returns:
        {
            "total": int, "extracted_root": str, "converted_root": str,
            "manifest_path": str,
            "manifest": [ {..., "status": "pending", "converted_path": None,
                            "error": None}, ... ],  # original execution order
        }
    """
    extracted_root = os.path.join(output_path, "extracted")
    converted_root = os.path.join(output_path, "converted")

    _report(progress_cb, stage="Scanning repository", percent=0.0,
             detail=f"{len(find_sql_files(local_path))} SQL file(s) found")

    _report(progress_cb, stage="Extracting SQL objects", percent=50.0,
             detail="Splitting files into individual objects")
    manifest = extract_sql_objects(local_path, extracted_root)
    manifest.sort(key=lambda m: (m["source_file"], m["sequence"]))

    for entry in manifest:
        entry["status"] = "pending"
        entry["converted_path"] = None
        entry["error"] = None

    manifest_path = os.path.join(output_path, "manifest.json")
    write_manifest(manifest, manifest_path)

    _report(progress_cb, stage="Done", percent=100.0,
             detail=f"{len(manifest)} object(s) extracted")

    return {
        "total": len(manifest),
        "extracted_root": extracted_root,
        "converted_root": converted_root,
        "manifest_path": manifest_path,
        "manifest": manifest,
    }


def convert_objects(manifest_entries, converted_root, progress_cb=None, config=None,
                     generate_notebooks=True, lakehouse_name=None, full_manifest=None):
    """
    Convert a specific, caller-chosen list of already-extracted SQL objects
    (entries from extract_only()'s manifest, or a filtered subset of it --
    this is what lets the Review step send only the objects the user
    selected, never the whole repo automatically).

    Uses the same convert_sql_text() call as before; only the caller now
    controls which objects are included, and no file gets converted that
    wasn't explicitly passed in.

    full_manifest, if given, should be every extracted object for this
    repository (not just the ones being converted in this call) -- it's
    used once, up front, to compute a single repo-wide schema-name
    replacement set (see schema_mapper.compute_global_schema_replacements),
    so a schema mentioned only in a status string or a "USE SCHEMA ...;"
    statement in one object still gets corrected even if manifest_entries
    itself is a small subset that doesn't otherwise reference that schema.
    Falls back to manifest_entries itself if full_manifest isn't given.

    As of this version, every successful conversion also appends a
    PySpark cell to that object's medallion-layer notebook (see
    notebook_builder.py) -- e.g. a "gold" object's converted SQL gets
    wrapped in a spark.sql(...) cell appended to
    Gold_ReadyToBuild_Notebook.ipynb under <converted_root's parent>/notebooks/.
    This is additive only: the .sql file written to converted_root, the
    entry's status/converted_path/error, and the returned summary shape
    are all unchanged from before. Set generate_notebooks=False to skip
    this and get the previous behavior exactly.

    Returns:
        {"total": int, "converted": int, "failed": int, "files": [...]}
        -- "files" are the same dicts passed in, updated in place with
        status/converted_path/error (and, unless disabled, notebook_path),
        so the caller can merge them back into a full manifest.
    """
    if config is None:
        config, missing = get_config()
        if missing:
            raise AzureOpenAIError(
                "Missing Azure OpenAI configuration: " + ", ".join(missing) +
                ". Set these as environment variables, or create "
                "azure_openai_config.json (see azure_openai_config.example.json)."
            )

    if generate_notebooks:
        notebooks_root = os.path.join(os.path.dirname(converted_root), "notebooks")
        resolved_lakehouse_name = lakehouse_name or load_lakehouse_name()

    schema_replacements = compute_global_schema_replacements(full_manifest or manifest_entries)

    total = len(manifest_entries)
    converted_count = 0
    failed_count = 0

    for idx, entry in enumerate(manifest_entries, start=1):
        pct = round((idx - 1) / total * 100, 1) if total else 100.0
        label = entry.get("object_name") or entry.get("filename")
        _report(progress_cb, stage=f"Converting object {idx} of {total}",
                 percent=pct, detail=f"{entry.get('source_file')} :: {label}")

        try:
            with open(entry["extracted_path"], "r", encoding="utf-8", errors="replace") as f:
                sql_code = f.read()

            converted_sql = convert_sql_text(sql_code, entry["relative_path"], config,
                                              schema_replacements=schema_replacements)

            # The conversion output is now a PySpark notebook-cell snippet,
            # not SQL text -- give it a .py extension rather than
            # inheriting the .sql extension from the extracted source.
            converted_relative_path = os.path.splitext(entry["relative_path"])[0] + ".py"
            dest_path = os.path.join(converted_root, converted_relative_path)
            os.makedirs(os.path.dirname(dest_path), exist_ok=True)
            with open(dest_path, "w", encoding="utf-8") as f:
                f.write(converted_sql)

            entry["status"] = "converted"
            entry["converted_path"] = dest_path
            entry["error"] = None
            converted_count += 1

            if generate_notebooks:
                # Never let a notebook-generation problem affect the SQL
                # conversion result above -- it has already succeeded and
                # been recorded by this point.
                try:
                    entry["notebook_path"] = append_object_to_notebook(
                        entry, converted_sql, notebooks_root, lakehouse_name=resolved_lakehouse_name,
                    )
                except Exception as exc:
                    entry["notebook_path"] = None
                    entry["notebook_error"] = str(exc)

        except AzureOpenAIError as exc:
            entry["status"] = "failed"
            entry["converted_path"] = None
            entry["error"] = str(exc)
            failed_count += 1

        except OSError as exc:
            entry["status"] = "failed"
            entry["converted_path"] = None
            entry["error"] = f"File error: {exc}"
            failed_count += 1

        except Exception as exc:  # keep the whole run alive on unexpected per-object errors
            entry["status"] = "failed"
            entry["converted_path"] = None
            entry["error"] = f"Unexpected error: {exc}"
            failed_count += 1

    _report(progress_cb, stage="Done", percent=100.0,
             detail=f"{converted_count} converted, {failed_count} failed")

    return {"total": total, "converted": converted_count, "failed": failed_count,
            "files": manifest_entries}


def convert_objects_for_review(manifest_entries, review_root, progress_cb=None, config=None,
                                full_manifest=None):
    """
    Like convert_objects(), but stages the AI's output for human review
    instead of writing straight to converted_root and appending a
    notebook cell. This is the entry point the web UI's Code Review step
    uses: nothing lands in converted_root or a notebook until a human
    explicitly approves it via approve_object() below. Rejecting via
    reject_object() means it never does.

    Uses the same convert_sql_text() call as convert_objects() -- the
    conversion step itself is identical; only what happens to the result
    differs (staged for review here, vs. written straight through there).

    Returns:
        {"total": int, "staged": int, "failed": int, "files": [...]}
        -- "files" are the same dicts passed in, updated in place with
        status ("pending_review" or "failed") and review_path.
    """
    if config is None:
        config, missing = get_config()
        if missing:
            raise AzureOpenAIError(
                "Missing Azure OpenAI configuration: " + ", ".join(missing) +
                ". Set these as environment variables, or create "
                "azure_openai_config.json (see azure_openai_config.example.json)."
            )

    schema_replacements = compute_global_schema_replacements(full_manifest or manifest_entries)

    total = len(manifest_entries)
    staged_count = 0
    failed_count = 0

    for idx, entry in enumerate(manifest_entries, start=1):
        pct = round((idx - 1) / total * 100, 1) if total else 100.0
        label = entry.get("object_name") or entry.get("filename")
        _report(progress_cb, stage=f"Converting object {idx} of {total} for review",
                 percent=pct, detail=f"{entry.get('source_file')} :: {label}")

        try:
            with open(entry["extracted_path"], "r", encoding="utf-8", errors="replace") as f:
                sql_code = f.read()

            converted_code = convert_sql_text(sql_code, entry["relative_path"], config,
                                               schema_replacements=schema_replacements)

            review_relative_path = os.path.splitext(entry["relative_path"])[0] + ".py"
            review_path = os.path.join(review_root, review_relative_path)
            os.makedirs(os.path.dirname(review_path), exist_ok=True)
            with open(review_path, "w", encoding="utf-8") as f:
                f.write(converted_code)

            entry["status"] = "pending_review"
            entry["review_path"] = review_path
            entry["converted_path"] = None
            entry["notebook_path"] = None
            entry["error"] = None
            staged_count += 1

        except AzureOpenAIError as exc:
            entry["status"] = "failed"
            entry["review_path"] = None
            entry["error"] = str(exc)
            failed_count += 1

        except OSError as exc:
            entry["status"] = "failed"
            entry["review_path"] = None
            entry["error"] = f"File error: {exc}"
            failed_count += 1

        except Exception as exc:  # keep the whole run alive on unexpected per-object errors
            entry["status"] = "failed"
            entry["review_path"] = None
            entry["error"] = f"Unexpected error: {exc}"
            failed_count += 1

    _report(progress_cb, stage="Done", percent=100.0,
             detail=f"{staged_count} staged for review, {failed_count} failed")

    return {"total": total, "staged": staged_count, "failed": failed_count, "files": manifest_entries}


def approve_object(entry, final_code, converted_root, notebooks_root, lakehouse_name=None):
    """
    Promote a "pending_review" object to "converted": write the
    (possibly human-edited) final code to converted_root and append its
    notebook cell. Nothing is written to either location before this is
    explicitly called -- this is the only path into converted_root or a
    notebook for anything that went through the review queue.
    """
    converted_relative_path = os.path.splitext(entry["relative_path"])[0] + ".py"
    dest_path = os.path.join(converted_root, converted_relative_path)
    os.makedirs(os.path.dirname(dest_path), exist_ok=True)
    with open(dest_path, "w", encoding="utf-8") as f:
        f.write(final_code)

    entry["status"] = "converted"
    entry["converted_path"] = dest_path
    entry["error"] = None

    try:
        entry["notebook_path"] = append_object_to_notebook(
            entry, final_code, notebooks_root, lakehouse_name=lakehouse_name or load_lakehouse_name(),
        )
    except Exception as exc:  # never let a notebook problem undo an already-approved conversion
        entry["notebook_path"] = None
        entry["notebook_error"] = str(exc)

    return entry


def reject_object(entry, reason=None):
    """
    Mark a "pending_review" object as rejected. Nothing is written to
    converted_root or a notebook for it -- the staged review file is left
    in place (under review_root) for reference, but is never promoted.
    """
    entry["status"] = "rejected"
    entry["converted_path"] = None
    entry["notebook_path"] = None
    entry["error"] = reason or "Rejected during review"
    return entry


def convert_repository(local_path, output_path, progress_cb=None, config=None):
    """
    Convenience wrapper kept for non-interactive / programmatic use: runs
    extraction and then converts every extracted object, with no review
    step in between. The web UI no longer calls this directly -- it calls
    extract_only() then convert_objects() with a user-selected subset --
    but this remains for scripts or tests that want the old one-shot
    behavior.

    Returns the same shape as before: {"total", "converted", "failed",
    "extracted_root", "converted_root", "manifest_path", "files"}.
    """
    extraction = extract_only(local_path, output_path, progress_cb=progress_cb)

    if extraction["total"] == 0:
        return {"total": 0, "converted": 0, "failed": 0,
                "extracted_root": extraction["extracted_root"],
                "converted_root": extraction["converted_root"],
                "manifest_path": extraction["manifest_path"], "files": []}

    result = convert_objects(extraction["manifest"], extraction["converted_root"],
                              progress_cb=progress_cb, config=config)
    write_manifest(result["files"], extraction["manifest_path"])

    result["extracted_root"] = extraction["extracted_root"]
    result["converted_root"] = extraction["converted_root"]
    result["manifest_path"] = extraction["manifest_path"]
    return result
