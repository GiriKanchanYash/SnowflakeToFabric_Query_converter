"""
Schema-name mapping: rewrites Snowflake schema names to the schemas that
already exist in the target Fabric Lakehouse (raw_vault / business_vault /
information_mart, per the screenshot of the actual Lakehouse Explorer).

This is a different concern from extractor.py's layer_mapping.json, which
decides which *notebook* (Bronze/Silver/Gold) an object's cell goes into.
This module decides what schema *name* appears inside the generated
code's table/view references -- e.g. a reference to SAP_STG.AUFK in the
original Snowflake SQL must become raw_vault.AUFK in the generated code,
never retaining "SAP_STG".

The rule is enforced two ways, matching the pattern already used for the
PySpark-safety-net in converter.py: the prompt asks the model to use the
mapped names itself (see converter.build_system_prompt()), and this
module's apply_schema_replacements() deterministically rewrites any
executable-code occurrence of an original schema name that the model
didn't rename -- so the rule holds regardless of model compliance.
"""

import json
import os
import re

SCHEMA_MAPPING_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "schema_mapping.json")

# Matched by keyword contained in the original schema name (case-insensitive),
# same two-tier style as extractor.infer_layer(): try an exact match first,
# then fall back to substring/keyword matching.
DEFAULT_SCHEMA_MAPPING = {
    "STG": "raw_vault",
    "VAULT": "business_vault",
    "MART": "information_mart",
}


def load_schema_mapping():
    if os.path.isfile(SCHEMA_MAPPING_FILE):
        try:
            with open(SCHEMA_MAPPING_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            return {str(k).upper(): str(v) for k, v in raw.items()}
        except (OSError, json.JSONDecodeError):
            pass
    return dict(DEFAULT_SCHEMA_MAPPING)


def match_target_schema(schema_name, mapping):
    """Exact (case-insensitive) match first, then keyword/substring match."""
    if not schema_name:
        return None
    upper = schema_name.upper()
    if upper in mapping:
        return mapping[upper]
    for keyword, target in mapping.items():
        if keyword in upper:
            return target
    return None


# Matches 2- or 3-part dotted identifiers made of plain SQL identifier
# characters (db.schema.object or schema.object). This is run against the
# *original* Snowflake SQL, a well-formed, known-shape input -- safe to
# pattern-match, unlike scanning arbitrary generated code for the same
# shape (see apply_schema_replacements for why that's handled differently).
_QUALIFIED_NAME_RE = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b"
    r"|\b([A-Za-z_][A-Za-z0-9_]*)\.([A-Za-z_][A-Za-z0-9_]*)\b"
)


def find_source_schemas(sql_text):
    """
    Collect every distinct schema name referenced anywhere in one object's
    original SQL -- a single object (e.g. a procedure that joins across
    layers) can reference more than one schema, so this returns a set,
    not a single value.
    """
    schemas = set()
    for m in _QUALIFIED_NAME_RE.finditer(sql_text):
        if m.group(2):       # db.schema.object -> schema is group 2
            schemas.add(m.group(2))
        elif m.group(4):     # schema.object     -> schema is group 4
            schemas.add(m.group(4))
    return schemas


def resolve_schema_replacements(original_sql, mapping=None):
    """
    For one object's original (Snowflake) SQL text, return {original
    schema string -> target Fabric schema} for every schema referenced in
    it that matches the configured mapping. Schemas with no match are
    simply absent from the result (left alone).
    """
    mapping = mapping or load_schema_mapping()
    replacements = {}
    for schema in find_source_schemas(original_sql):
        target = match_target_schema(schema, mapping)
        if target:
            replacements[schema] = target
    return replacements


def apply_schema_replacements(text, replacements):
    """
    Deterministically rewrite every occurrence of a known original schema
    name to its mapped Fabric schema name -- not just dot-qualified
    references, but any standalone mention (a status message, a
    "USE SCHEMA ...;" statement, etc.), since the requirement is that the
    original name never appears in generated code at all, not just in
    table references.

    The one deliberate exception: a "# original name: ..." traceability
    comment (added per SYSTEM_PROMPT_TEMPLATE) keeps the true original
    name, since that's the whole point of it existing.
    """
    if not replacements:
        return text

    patterns = [
        (re.compile(r"(?<![A-Za-z0-9_])" + re.escape(original) + r"(?![A-Za-z0-9_])"), target)
        for original, target in replacements.items()
    ]
    original_name_comment_re = re.compile(r"^\s*#\s*original name", re.IGNORECASE)

    out_lines = []
    for line in text.splitlines(keepends=True):
        if original_name_comment_re.match(line):
            out_lines.append(line)
            continue
        for pattern, target in patterns:
            line = pattern.sub(target, line)
        out_lines.append(line)
    return "".join(out_lines)


def compute_global_schema_replacements(all_entries, mapping=None):
    """
    Build ONE repo-wide {original schema -> target schema} dict, rather
    than rediscovering it separately per object from that object's own
    text. This is what lets a schema mentioned only in a plain status
    string, a "USE SCHEMA ...;" statement, or a misleading comment still
    get corrected in some *other* object's output -- per-object discovery
    alone missed exactly those cases (confirmed by testing against the
    real repo: a status message reading "...FROM SAP_STG" with no
    trailing ".table", and a "USE SCHEMA SAP_STG;" statement, both slipped
    through per-object discovery since neither is a dot-qualified
    reference; a repo-wide scan catches both because SAP_STG is
    unambiguously a real schema elsewhere in the same repo).

    all_entries: the full extraction manifest (or any list of entries with
    "object_name" and/or "extracted_path") to scan -- not just the subset
    currently being converted, so the result is stable across separate
    batches of the same repository.
    """
    mapping = mapping or load_schema_mapping()
    schemas = set()

    for entry in all_entries:
        object_name = entry.get("object_name")
        if object_name:
            parts = object_name.split(".")
            if len(parts) >= 2:
                schemas.add(parts[-2])  # the object's own home schema -- reliably

        extracted_path = entry.get("extracted_path")
        if extracted_path and os.path.isfile(extracted_path):
            try:
                with open(extracted_path, "r", encoding="utf-8", errors="replace") as f:
                    schemas |= find_source_schemas(f.read())
            except OSError:
                pass

    replacements = {}
    for schema in schemas:
        target = match_target_schema(schema, mapping)
        if target:
            replacements[schema] = target
    return replacements


def format_mapping_rules(mapping=None):
    """Render the current mapping as prompt text, so editing
    schema_mapping.json changes what the model is told without a code change."""
    mapping = mapping or load_schema_mapping()
    return "\n".join(f"      any schema containing {keyword:<10} -> {target}" for keyword, target in mapping.items())
