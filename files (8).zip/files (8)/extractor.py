"""
SQL object extraction — splits multi-statement Snowflake .sql files into
one file per top-level object (table, view, procedure, function, dynamic
table, standalone statement, ...).

This exists because sending an entire .sql file to Azure OpenAI doesn't
scale: some files hold dozens of objects and blow past the model's token
limit. Extraction lets the existing conversion step (convert_sql_text in
converter.py, unchanged) process exactly one object per API call.

The splitter is a small state-machine tokenizer, not a regex split on
";" -- a naive split breaks on the semicolons that appear inside
Snowflake procedure bodies (`$$ ... $$`) and inside string literals. It
tracks:
    - single-quoted strings ('...', with '' as an escaped quote)
    - double-quoted identifiers ("...", with "" as an escaped quote)
    - dollar-quoted bodies ($$ ... $$ or $tag$ ... $tag$)
    - line comments (-- ... end of line)
    - block comments (/* ... */)
and only treats a semicolon as a statement boundary when none of those
are open.
"""

import json
import os
import re

SQL_EXTENSIONS = (".sql",)
IGNORE_DIRS = {".git", ".github", "node_modules", "__pycache__", ".venv", "venv"}

# Optional local override, checked before falling back to the built-in
# guess below. Lets a repo whose schemas don't match the default guess
# still get sorted into bronze/silver/gold without touching this file.
LAYER_MAPPING_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "layer_mapping.json")

# Best-effort default guess at schema-name -> medallion-layer, based on
# common Snowflake/Data-Vault naming conventions (staging schemas land in
# bronze, a raw/data-vault layer lands in silver, a mart/reporting layer
# lands in gold). Matching is case-insensitive and by substring, so
# "SAP_STG" matches "STG" and "INFORMATION_MART" matches "MART".
DEFAULT_LAYER_KEYWORDS = {
    "bronze": ["STG", "STAGE", "STAGING", "RAW", "BRONZE", "LANDING"],
    "silver": ["VAULT", "SILVER", "CONFORMED", "INTEGRATION"],
    "gold": ["MART", "GOLD", "REPORTING", "CONSUMPTION", "SEMANTIC"],
}
UNCLASSIFIED_LAYER = "unclassified"

DOLLAR_TAG_RE = re.compile(r"\$[A-Za-z0-9_]*\$")

# CREATE [OR REPLACE] [TRANSIENT|TEMP...] <OBJECT TYPE> [IF NOT EXISTS] <name>
CREATE_RE = re.compile(
    r"CREATE\s+(?:OR\s+REPLACE\s+)?(?:TEMP(?:ORARY)?\s+)?(?:TRANSIENT\s+)?"
    r"(TABLE|DYNAMIC\s+TABLE|VIEW|MATERIALIZED\s+VIEW|PROCEDURE|FUNCTION|"
    r"SEQUENCE|STAGE|FILE\s+FORMAT|TASK|STREAM|SCHEMA|DATABASE|WAREHOUSE|"
    r"MASKING\s+POLICY|ROW\s+ACCESS\s+POLICY|PIPE|TAG)\s+"
    r"(?:IF\s+NOT\s+EXISTS\s+)?"
    r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})',
    re.IGNORECASE,
)

# Fallback patterns for statements that aren't CREATE (ALTER/INSERT/UPDATE/
# DELETE/MERGE/GRANT ...) so we can still derive a meaningful name.
FALLBACK_PATTERNS = [
    (re.compile(r"ALTER\s+(?:DYNAMIC\s+)?TABLE\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "ALTER_TABLE"),
    (re.compile(r"ALTER\s+VIEW\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "ALTER_VIEW"),
    (re.compile(r"INSERT\s+INTO\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "INSERT"),
    (re.compile(r"UPDATE\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "UPDATE"),
    (re.compile(r"DELETE\s+FROM\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "DELETE"),
    (re.compile(r"MERGE\s+INTO\s+" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "MERGE"),
    (re.compile(r"GRANT\s+.*?\bON\s+(?:TABLE\s+)?" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE | re.DOTALL), "GRANT"),
    (re.compile(r"DROP\s+\w+\s+(?:IF\s+EXISTS\s+)?" r'("?[A-Za-z0-9_]+"?(?:\."?[A-Za-z0-9_]+"?){0,2})', re.IGNORECASE), "DROP"),
]


def find_sql_files(root_dir):
    """Recursively collect .sql file paths under root_dir, skipping VCS/build dirs."""
    matches = []
    for dirpath, dirnames, filenames in os.walk(root_dir):
        dirnames[:] = [d for d in dirnames if d not in IGNORE_DIRS and not d.startswith(".")]
        for name in filenames:
            if name.lower().endswith(SQL_EXTENSIONS):
                matches.append(os.path.join(dirpath, name))
    matches.sort()
    return matches


def split_sql_statements(sql_text):
    """
    Split a SQL script into top-level statements, respecting string
    literals, quoted identifiers, dollar-quoted bodies, and comments so a
    semicolon inside any of those doesn't get treated as a boundary.

    Returns a list of (statement_text, start_offset, end_offset) tuples,
    trimmed of surrounding whitespace but otherwise verbatim.
    """
    statements = []
    n = len(sql_text)
    i = 0
    buf_start = 0
    state = "normal"
    dollar_tag = None

    def flush(end):
        raw = sql_text[buf_start:end]
        stripped = raw.strip()
        if stripped:
            # Recompute precise start/end within the original text for the
            # trimmed content, for accurate line-number reporting later.
            lstrip_len = len(raw) - len(raw.lstrip())
            real_start = buf_start + lstrip_len
            real_end = real_start + len(stripped)
            statements.append((stripped, real_start, real_end))

    while i < n:
        c = sql_text[i]

        if state == "normal":
            if c == "'":
                state = "single_quote"
                i += 1
                continue
            if c == '"':
                state = "double_quote"
                i += 1
                continue
            if c == "$":
                m = DOLLAR_TAG_RE.match(sql_text, i)
                if m:
                    dollar_tag = m.group(0)
                    state = "dollar_quote"
                    i = m.end()
                    continue
            if c == "-" and i + 1 < n and sql_text[i + 1] == "-":
                state = "line_comment"
                i += 2
                continue
            if c == "/" and i + 1 < n and sql_text[i + 1] == "*":
                state = "block_comment"
                i += 2
                continue
            if c == ";":
                flush(i + 1)
                buf_start = i + 1
                i += 1
                continue
            i += 1
            continue

        if state == "single_quote":
            if c == "'":
                if i + 1 < n and sql_text[i + 1] == "'":
                    i += 2
                    continue
                state = "normal"
            i += 1
            continue

        if state == "double_quote":
            if c == '"':
                if i + 1 < n and sql_text[i + 1] == '"':
                    i += 2
                    continue
                state = "normal"
            i += 1
            continue

        if state == "dollar_quote":
            if sql_text.startswith(dollar_tag, i):
                i += len(dollar_tag)
                state = "normal"
                dollar_tag = None
                continue
            i += 1
            continue

        if state == "line_comment":
            if c == "\n":
                state = "normal"
            i += 1
            continue

        if state == "block_comment":
            if c == "*" and i + 1 < n and sql_text[i + 1] == "/":
                i += 2
                state = "normal"
                continue
            i += 1
            continue

    flush(n)
    return statements


def identify_object(statement_text):
    """
    Best-effort extraction of (object_type, qualified_name) from a single
    statement. Falls back to (None, None) if nothing recognizable is found
    (e.g. a bare SELECT), in which case the caller assigns a generic name.
    """
    match = CREATE_RE.search(statement_text)
    if match:
        obj_type = re.sub(r"\s+", "_", match.group(1).upper())
        name = match.group(2).replace('"', "")
        return obj_type, name

    for pattern, label in FALLBACK_PATTERNS:
        match = pattern.search(statement_text)
        if match:
            name = match.group(1).replace('"', "")
            return label, name

    return None, None


def load_layer_mapping():
    """
    Load an explicit schema -> layer mapping from layer_mapping.json if
    present, e.g. {"SAP_STG": "bronze", "RAW_VAULT": "silver",
    "INFORMATION_MART": "gold"}. Keys are matched case-insensitively and
    exactly against the schema name. If the file doesn't exist, callers
    fall back to the keyword-based DEFAULT_LAYER_KEYWORDS guess.
    """
    if os.path.isfile(LAYER_MAPPING_FILE):
        try:
            with open(LAYER_MAPPING_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
            return {str(k).upper(): str(v).lower() for k, v in raw.items()}
        except (OSError, json.JSONDecodeError):
            return {}
    return {}


def _extract_schema(object_name):
    """CLEAR_TO_BUILD_DEV.SAP_STG.AUFK -> 'SAP_STG'. Returns None if the
    name isn't at least database.schema.object (or schema.object)."""
    if not object_name:
        return None
    parts = object_name.split(".")
    if len(parts) >= 2:
        return parts[-2].upper()
    return None


def infer_layer(object_name, source_file, layer_mapping):
    """
    Decide which medallion layer (bronze/silver/gold, or "unclassified")
    an object belongs to, so extraction can group output by layer instead
    of (or alongside) by source file. Tries, in order:
      1. An exact schema match against layer_mapping.json, if configured.
      2. A keyword guess against the schema name (DEFAULT_LAYER_KEYWORDS).
      3. The same keyword guess against the source filename, for objects
         with no schema-qualified name (e.g. a bare CREATE TABLE, or a
         fallback statement that couldn't be parsed for a name).
      4. "unclassified", if nothing matched -- surfaced plainly rather
         than silently guessed wrong.
    """
    schema = _extract_schema(object_name)

    if schema and schema in layer_mapping:
        return layer_mapping[schema]

    def keyword_guess(text):
        if not text:
            return None
        upper = text.upper()
        for layer, keywords in DEFAULT_LAYER_KEYWORDS.items():
            if any(kw in upper for kw in keywords):
                return layer
        return None

    layer = keyword_guess(schema)
    if layer:
        return layer

    layer = keyword_guess(source_file)
    if layer:
        return layer

    return UNCLASSIFIED_LAYER


def sanitize_filename_part(text):
    text = re.sub(r"[^A-Za-z0-9_]+", "_", text)
    text = re.sub(r"_+", "_", text).strip("_")
    return text or "OBJECT"


def build_filename(obj_type, name, fallback_stub, used_names):
    """
    Build a descriptive, unique .sql filename for one extracted object.
    Mirrors the convention from the brief: dotted qualified names become
    underscore-joined, e.g. CLEAR_TO_BUILD_DEV.INFORMATION_MART.SP_X ->
    CLEAR_TO_BUILD_DEV_INFORMATION_MART_SP_X.sql. Duplicates get a
    trailing _2, _3, ... suffix.
    """
    if name:
        base = sanitize_filename_part(name.replace(".", "_"))
    else:
        base = sanitize_filename_part(f"{fallback_stub}_{obj_type or 'STATEMENT'}")

    candidate = base
    n = 2
    while candidate in used_names:
        candidate = f"{base}_{n}"
        n += 1
    used_names.add(candidate)
    return candidate + ".sql"


def extract_sql_objects(local_path, extracted_root):
    """
    Walk local_path for .sql files, split each into top-level SQL objects,
    and write each object to its own file under extracted_root, grouped
    by medallion layer (bronze/silver/gold/unclassified -- see
    infer_layer()) and then by source file, for traceability.

    Returns a manifest: list of dicts, one per extracted object, each with
    enough information to trace it back to its source file and position,
    and in original execution order per source file:
        {
            "source_file": relative path of the original .sql file,
            "sequence": 1-based order within that source file,
            "object_type": "PROCEDURE" | "TABLE" | ... | None,
            "object_name": qualified name as written in the SQL, or None,
            "layer": "bronze" | "silver" | "gold" | "unclassified",
            "filename": generated filename, e.g. "X_Y_Z.sql",
            "extracted_path": absolute path of the extracted object file,
            "relative_path": path of the extracted file relative to
                extracted_root (this is reused verbatim as the relative
                path under the conversion output directory too),
            "line_start": 1-based line number where the statement begins,
            "line_end": 1-based line number where the statement ends,
        }
    """
    manifest = []
    sql_files = find_sql_files(local_path)
    layer_mapping = load_layer_mapping()

    for src_path in sql_files:
        rel_source = os.path.relpath(src_path, local_path)
        source_stub = sanitize_filename_part(os.path.splitext(os.path.basename(src_path))[0])

        with open(src_path, "r", encoding="utf-8", errors="replace") as f:
            text = f.read()

        statements = split_sql_statements(text)
        used_names_by_dir = {}

        for seq, (stmt_text, start_off, end_off) in enumerate(statements, start=1):
            obj_type, obj_name = identify_object(stmt_text)
            layer = infer_layer(obj_name, rel_source, layer_mapping)

            dest_dir = os.path.join(extracted_root, layer, source_stub)
            os.makedirs(dest_dir, exist_ok=True)
            used_names = used_names_by_dir.setdefault(dest_dir, set())

            filename = build_filename(obj_type, obj_name, f"{source_stub}_STMT_{seq:03d}", used_names)

            dest_path = os.path.join(dest_dir, filename)
            with open(dest_path, "w", encoding="utf-8") as f:
                f.write(stmt_text.rstrip() + "\n")

            line_start = text.count("\n", 0, start_off) + 1
            line_end = text.count("\n", 0, end_off) + 1
            relative_path = os.path.relpath(dest_path, extracted_root)

            manifest.append({
                "source_file": rel_source,
                "sequence": seq,
                "object_type": obj_type,
                "object_name": obj_name,
                "layer": layer,
                "filename": filename,
                "extracted_path": dest_path,
                "relative_path": relative_path,
                "line_start": line_start,
                "line_end": line_end,
            })

    return manifest


def write_manifest(manifest, path):
    with open(path, "w", encoding="utf-8") as f:
        json.dump(manifest, f, indent=2)


def load_manifest(path):
    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)
