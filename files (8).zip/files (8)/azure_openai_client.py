"""
Minimal Azure OpenAI chat-completions client.

Pure standard library (urllib) — no `openai` package, no third-party
dependencies, consistent with the rest of this project. Talks directly to
the Azure OpenAI REST API:

    POST {endpoint}/openai/deployments/{deployment}/chat/completions?api-version={version}
    header: api-key: <key>
"""

import json
import os
import time
import urllib.error
import urllib.request

# Optional local config file, checked before falling back to environment
# variables. Never commit this file — add it to .gitignore. See
# azure_openai_config.example.json for the expected shape.
CONFIG_FILE = os.path.join(os.path.dirname(os.path.abspath(__file__)), "azure_openai_config.json")

DEFAULT_API_VERSION = "2024-08-01-preview"


class AzureOpenAIError(Exception):
    """Raised for any failure talking to Azure OpenAI (config, network, API)."""


def _load_file_config():
    if os.path.isfile(CONFIG_FILE):
        try:
            with open(CONFIG_FILE, "r", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, json.JSONDecodeError):
            return {}
    return {}


def get_config():
    """
    Resolve Azure OpenAI settings from (in priority order) the local
    azure_openai_config.json file, then environment variables.

    Returns (config_dict, missing_fields). If missing_fields is non-empty,
    config_dict should not be used to make requests yet.
    """
    file_cfg = _load_file_config()

    def pick(file_key, env_name):
        return (file_cfg.get(file_key) or os.environ.get(env_name, "")).strip()

    endpoint = pick("endpoint", "AZURE_OPENAI_ENDPOINT").rstrip("/")
    api_key = pick("api_key", "AZURE_OPENAI_API_KEY")
    deployment = pick("deployment", "AZURE_OPENAI_DEPLOYMENT")
    api_version = pick("api_version", "AZURE_OPENAI_API_VERSION") or DEFAULT_API_VERSION

    config = {
        "endpoint": endpoint,
        "api_key": api_key,
        "deployment": deployment,
        "api_version": api_version,
    }

    missing = []
    if not endpoint:
        missing.append("AZURE_OPENAI_ENDPOINT")
    if not api_key:
        missing.append("AZURE_OPENAI_API_KEY")
    if not deployment:
        missing.append("AZURE_OPENAI_DEPLOYMENT")

    return config, missing


def chat_completion(messages, config, temperature=0, max_tokens=4000, timeout=90, max_retries=3):
    """
    Call Azure OpenAI's chat completions endpoint and return the assistant's
    reply text. Retries on rate limits (429) and transient server errors
    (5xx) with exponential backoff; raises AzureOpenAIError otherwise.
    """
    url = (
        f"{config['endpoint']}/openai/deployments/{config['deployment']}"
        f"/chat/completions?api-version={config['api_version']}"
    )
    body = json.dumps({
        "messages": messages,
        "temperature": temperature,
        "max_tokens": max_tokens,
    }).encode("utf-8")

    last_error = None
    for attempt in range(1, max_retries + 1):
        req = urllib.request.Request(url, data=body, method="POST")
        req.add_header("Content-Type", "application/json")
        req.add_header("api-key", config["api_key"])
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                payload = json.loads(resp.read().decode("utf-8"))
                choices = payload.get("choices") or []
                if not choices:
                    raise AzureOpenAIError("Azure OpenAI returned no choices in the response.")
                return choices[0]["message"]["content"]

        except urllib.error.HTTPError as exc:
            err_body = exc.read().decode("utf-8", errors="replace")
            last_error = f"HTTP {exc.code}: {err_body[:500]}"
            if exc.code == 429 or exc.code >= 500:
                time.sleep(min(2 ** attempt, 20))
                continue
            if exc.code == 401 or exc.code == 403:
                raise AzureOpenAIError(
                    "Azure OpenAI rejected the request (401/403). Check "
                    "AZURE_OPENAI_API_KEY and that the deployment name is correct."
                )
            if exc.code == 404:
                raise AzureOpenAIError(
                    "Azure OpenAI endpoint returned 404. Check "
                    "AZURE_OPENAI_ENDPOINT, AZURE_OPENAI_DEPLOYMENT, and "
                    "AZURE_OPENAI_API_VERSION."
                )
            raise AzureOpenAIError(last_error)

        except urllib.error.URLError as exc:
            last_error = f"Network error reaching Azure OpenAI: {exc.reason}"
            time.sleep(min(2 ** attempt, 20))
            continue

        except TimeoutError:
            last_error = "Azure OpenAI request timed out."
            time.sleep(min(2 ** attempt, 20))
            continue

    raise AzureOpenAIError(last_error or "Azure OpenAI request failed after retries.")
