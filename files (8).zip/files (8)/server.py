"""
Git Repository Clone UI + Snowflake -> Fabric SQL Conversion — backend.

Pure Python standard library only: http.server for the web server,
subprocess to drive the real `git` binary, threading for background jobs.
No Flask, no GitPython, no `openai` package — the Azure OpenAI call in
converter.py / azure_openai_client.py is a plain urllib REST request.

Run:
    python server.py
Then open:
    http://localhost:5000
"""

import json
import os
import re
import shutil
import stat
import subprocess
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import parse_qs, urlparse

from azure_openai_client import AzureOpenAIError, get_config as get_azure_config
from converter import approve_object, convert_objects, convert_objects_for_review, convert_repository, extract_only, reject_object
from extractor import load_manifest, write_manifest

HOST = "0.0.0.0"
PORT = 5000

BASE_DIR = os.path.dirname(os.path.abspath(__file__))

# Static files this server knows how to serve, and their content types.
STATIC_FILES = {
    "/": ("index.html", "text/html; charset=utf-8"),
    "/index.html": ("index.html", "text/html; charset=utf-8"),
    "/style.css": ("style.css", "text/css; charset=utf-8"),
    "/script.js": ("script.js", "application/javascript; charset=utf-8"),
}

BRANCH_NAME_RE = re.compile(r"^[A-Za-z0-9._\-/]+$")
REPO_URL_RE = re.compile(
    r"^(https?|git|ssh)://[^\s]+$|^[\w.\-]+@[\w.\-]+:[\w./\-]+(\.git)?$"
)

# In-memory job store shared across threads.
JOBS = {}
JOBS_LOCK = threading.Lock()

# Directories the /api/file read/write endpoints are allowed to touch --
# populated with an output_path's "extracted" (and "converted", for
# read-only viewing) root each time /api/extract completes. This is what
# lets the Review step open and save individual extracted .sql files
# without turning the endpoint into an arbitrary-path file server.
ALLOWED_FILE_ROOTS = set()
ALLOWED_FILE_ROOTS_LOCK = threading.Lock()


def _register_allowed_root(path):
    with ALLOWED_FILE_ROOTS_LOCK:
        ALLOWED_FILE_ROOTS.add(os.path.abspath(path))


def _path_is_allowed(path):
    abs_path = os.path.abspath(path)
    with ALLOWED_FILE_ROOTS_LOCK:
        roots = list(ALLOWED_FILE_ROOTS)
    for root in roots:
        try:
            if os.path.commonpath([abs_path, root]) == root:
                return True
        except ValueError:
            continue  # different drives on Windows, etc. -- just not a match
    return False


# --------------------------------------------------------------------------
# Validation helpers
# --------------------------------------------------------------------------

def validate_repo_url(repo_url: str):
    if not repo_url or not repo_url.strip():
        return "Repository URL is required."
    if not REPO_URL_RE.match(repo_url.strip()):
        return (
            "That doesn't look like a valid Git URL. Use an https:// URL "
            "(e.g. https://github.com/org/repo.git) or an SSH form "
            "(e.g. git@github.com:org/repo.git)."
        )
    return None


def validate_branch(branch: str):
    if not branch:
        return None  # optional, defaults to main
    if not BRANCH_NAME_RE.match(branch):
        return (
            "Branch name contains invalid characters. Use letters, numbers, "
            "dots, dashes, underscores, or slashes only."
        )
    if branch.startswith("/") or branch.endswith("/") or ".." in branch:
        return "Branch name is not valid."
    return None


def validate_local_path(local_path: str):
    if not local_path or not local_path.strip():
        return "Local clone directory is required."
    local_path = local_path.strip()
    if "\x00" in local_path:
        return "Local clone directory contains invalid characters."
    parent = os.path.dirname(os.path.abspath(local_path)) or "/"
    probe = parent
    while not os.path.exists(probe):
        new_probe = os.path.dirname(probe)
        if new_probe == probe:
            break
        probe = new_probe
    if os.path.exists(probe) and not os.access(probe, os.W_OK):
        return f"No permission to write under '{probe}'."
    return None


def check_git_installed():
    if shutil.which("git") is None:
        return (
            "Git does not appear to be installed on this machine. Install "
            "Git and ensure it is on your PATH."
        )
    return None


def repo_name_from_url(repo_url: str) -> str:
    path = urlparse(repo_url).path or repo_url
    name = path.rstrip("/").split("/")[-1]
    if name.endswith(".git"):
        name = name[:-4]
    return name or "repository"


def _on_rm_error(func, path, exc_info):
    """shutil.rmtree error handler: clear read-only bits and retry."""
    os.chmod(path, stat.S_IWRITE)
    func(path)


def _set_job(job_id, **kwargs):
    if not job_id:
        return
    with JOBS_LOCK:
        if job_id in JOBS:
            JOBS[job_id].update(kwargs)


# --------------------------------------------------------------------------
# Git operations (subprocess only)
# --------------------------------------------------------------------------

def run_git(args, cwd=None, timeout=None):
    """Run a git command, returning (returncode, stdout, stderr)."""
    proc = subprocess.run(
        ["git"] + args,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=timeout,
    )
    return proc.returncode, proc.stdout, proc.stderr


def classify_git_error(stderr_text):
    """Map git's stderr onto one of our error codes + friendly message."""
    text = (stderr_text or "").lower()
    if any(k in text for k in (
        "could not resolve host", "unable to access", "couldn't connect",
        "timed out", "network is unreachable", "connection refused",
        "failed to connect",
    )):
        return "network", ("Network error: could not reach the remote "
                            "repository. Check your connection and the URL.")
    if any(k in text for k in (
        "could not read username", "authentication", "permission denied",
        "access denied", "403", "could not read password",
    )):
        return "repo_not_found", ("Repository not found, or it is private. "
                                   "This tool only supports public repositories.")
    if "not found" in text or "repository" in text and "does not exist" in text:
        return "repo_not_found", "Repository not found. Check the URL and that the repository is public."
    return "git_error", f"Git reported an error: {stderr_text.strip() or 'unknown failure'}"


def preflight_check(repo_url, branch, timeout=15):
    """
    Probe the remote with `git ls-remote` before attempting a real clone.
    This is what lets us tell a bad URL, a private/missing repo, a missing
    branch, and a network failure apart with an accurate message, rather
    than a single generic "git failed" error.

    Returns (error_code, message) on failure, or (None, None) if OK.
    """
    try:
        code, out, err = run_git(["ls-remote", "--heads", repo_url, branch], timeout=timeout)
    except subprocess.TimeoutExpired:
        return "network", "Could not reach the remote repository in time."

    if code != 0:
        return classify_git_error(err)
    if not out.strip():
        return "branch_not_found", f"Branch '{branch}' was not found in the remote repository."
    return None, None


PROGRESS_RE = re.compile(
    r"(Counting objects|Compressing objects|Receiving objects|Resolving deltas):\s+(\d+)%\s+\((\d+)/(\d+)\)"
)


def _stream_clone_progress(proc, job_id):
    """Read git's stderr line-by-line and translate it into job progress."""
    stderr_lines = []
    if proc.stderr is None:
        return stderr_lines
    for raw_line in iter(proc.stderr.readline, ""):
        if raw_line == "":
            break
        line = raw_line.strip()
        if not line:
            continue
        stderr_lines.append(line)
        match = PROGRESS_RE.search(line)
        if match:
            stage, pct, cur, total = match.groups()
            _set_job(job_id, stage=stage, percent=float(pct), detail=f"{cur}/{total}")
        elif line.lower().startswith("cloning into"):
            _set_job(job_id, stage="Starting clone", percent=0.0, detail=line)
    return stderr_lines


def clone_repository(repo_url, branch="main", local_path="", job_id=None, on_exists="cancel"):
    """
    Clone a public Git repository using the system `git` binary via
    subprocess (no third-party libraries).

    Args:
        repo_url: HTTPS/SSH URL of the public repository.
        branch: Branch to check out. Defaults to "main".
        local_path: Destination directory on disk.
        job_id: Optional id used to publish live progress to JOBS.
        on_exists: "cancel" (default) | "overwrite" | "pull".

    Returns:
        dict with keys: success, local_path, repo_name, branch, message, error.

    This function is the sole integration point for downstream consumers:
    on success, `local_path` is the directory the Snowflake -> Fabric SQL
    conversion pipeline should scan for .sql files.
    """
    branch = (branch or "main").strip() or "main"
    local_path = os.path.abspath(local_path.strip())
    repo_name = repo_name_from_url(repo_url)

    git_error = check_git_installed()
    if git_error:
        return {"success": False, "error": "git_missing", "local_path": None,
                "repo_name": None, "branch": None, "message": git_error}

    dest_exists = (
        os.path.isdir(local_path) and os.listdir(local_path)
    ) or (os.path.exists(local_path) and not os.path.isdir(local_path))

    try:
        if dest_exists:
            if on_exists == "cancel":
                msg = f"'{local_path}' already exists and is not empty."
                return {"success": False, "error": "exists", "local_path": local_path,
                        "repo_name": repo_name, "branch": branch, "message": msg}

            if on_exists == "overwrite":
                _set_job(job_id, stage="Removing existing directory", percent=None)
                shutil.rmtree(local_path, onerror=_on_rm_error)

            elif on_exists == "pull":
                _set_job(job_id, stage="Updating existing repository", percent=None)

                is_repo_code, _, _ = run_git(["rev-parse", "--is-inside-work-tree"], cwd=local_path)
                if is_repo_code != 0:
                    msg = (f"'{local_path}' exists but is not a Git repository, "
                           "so it can't be updated. Choose a different folder "
                           "or overwrite it instead.")
                    return {"success": False, "error": "not_a_repo", "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": msg}

                origin_code, origin_url, _ = run_git(["remote", "get-url", "origin"], cwd=local_path)
                origin_url = origin_url.strip()
                if origin_code != 0 or not origin_url:
                    msg = f"'{local_path}' has no 'origin' remote configured."
                    return {"success": False, "error": "no_remote", "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": msg}

                error_code, message = preflight_check(origin_url, branch)
                if error_code:
                    return {"success": False, "error": error_code, "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": message}

                _set_job(job_id, stage="Fetching updates", percent=None)
                fetch_code, _, fetch_err = run_git(["fetch", "origin", branch], cwd=local_path)
                if fetch_code != 0:
                    error_code, message = classify_git_error(fetch_err)
                    return {"success": False, "error": error_code, "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": message}

                _set_job(job_id, stage="Checking out branch", percent=None)
                checkout_code, _, checkout_err = run_git(["checkout", branch], cwd=local_path)
                if checkout_code != 0:
                    msg = f"Branch '{branch}' was not found in the remote repository."
                    return {"success": False, "error": "branch_not_found", "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": msg}

                _set_job(job_id, stage="Pulling latest changes", percent=None)
                pull_code, _, pull_err = run_git(["pull", "origin", branch], cwd=local_path)
                if pull_code != 0:
                    error_code, message = classify_git_error(pull_err)
                    return {"success": False, "error": error_code, "local_path": local_path,
                            "repo_name": repo_name, "branch": branch, "message": message}

                _set_job(job_id, stage="Done", percent=100.0)
                msg = f"Pulled latest changes for branch '{branch}'."
                return {"success": True, "error": None, "local_path": local_path,
                        "repo_name": repo_name, "branch": branch, "message": msg}

        # Fresh clone
        _set_job(job_id, stage="Checking remote", percent=None)
        error_code, message = preflight_check(repo_url, branch)
        if error_code:
            return {"success": False, "error": error_code, "local_path": None,
                    "repo_name": repo_name, "branch": branch, "message": message}

        os.makedirs(local_path, exist_ok=True)
        _set_job(job_id, stage="Starting clone", percent=0.0)

        proc = subprocess.Popen(
            ["git", "clone", "--progress", "--branch", branch, "--single-branch",
             repo_url, local_path],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
            bufsize=1,
        )
        stderr_lines = _stream_clone_progress(proc, job_id)
        proc.wait()

        if proc.returncode != 0:
            error_code, message = classify_git_error("\n".join(stderr_lines))
            if os.path.isdir(local_path) and not os.listdir(local_path):
                shutil.rmtree(local_path, ignore_errors=True)
            return {"success": False, "error": error_code, "local_path": None,
                    "repo_name": repo_name, "branch": branch, "message": message}

        _set_job(job_id, stage="Done", percent=100.0)
        msg = f"Cloned '{repo_name}' (branch '{branch}') to '{local_path}'."
        return {"success": True, "error": None, "local_path": local_path,
                "repo_name": repo_name, "branch": branch, "message": msg}

    except PermissionError:
        message = f"Permission denied when writing to '{local_path}'."
        return {"success": False, "error": "permission", "local_path": None,
                "repo_name": repo_name, "branch": branch, "message": message}

    except OSError as exc:
        message = f"Could not access '{local_path}': {exc.strerror or exc}"
        return {"success": False, "error": "os_error", "local_path": None,
                "repo_name": repo_name, "branch": branch, "message": message}

    except Exception as exc:  # last-resort guard so the server never crashes
        message = f"Unexpected error while cloning: {exc}"
        return {"success": False, "error": "unknown", "local_path": None,
                "repo_name": repo_name, "branch": branch, "message": message}


# --------------------------------------------------------------------------
# HTTP server (stdlib http.server, no framework)
# --------------------------------------------------------------------------

class CloneRequestHandler(BaseHTTPRequestHandler):
    server_version = "GitCloneUI/1.0"

    # Quiet the default per-request console logging noise a little.
    def log_message(self, fmt, *args):
        print(f"[{self.log_date_time_string()}] {fmt % args}")

    def _send_json(self, status, payload):
        body = json.dumps(payload).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _send_file(self, filename, content_type):
        path = os.path.join(BASE_DIR, filename)
        if not os.path.isfile(path):
            self._send_json(500, {
                "message": f"Missing file: {filename}. Make sure it sits "
                           f"next to server.py in {BASE_DIR}."
            })
            return
        with open(path, "rb") as f:
            body = f.read()
        self.send_response(200)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def _job_status_response(self, job_id):
        """Shared by /api/clone/status/ and /api/convert/status/ -- both
        just look up the same generic job record shape."""
        with JOBS_LOCK:
            job = JOBS.get(job_id)
        if job is None:
            self._send_json(404, {"success": False, "message": "Unknown job id."})
        else:
            self._send_json(200, job)

    # ---- GET ----

    def do_GET(self):
        parsed = urlparse(self.path)
        path = parsed.path

        if path in STATIC_FILES:
            filename, content_type = STATIC_FILES[path]
            self._send_file(filename, content_type)
            return

        if (path.startswith("/api/clone/status/") or path.startswith("/api/convert/status/")
                or path.startswith("/api/extract/status/")):
            job_id = path.rsplit("/", 1)[-1]
            self._job_status_response(job_id)
            return

        if path == "/api/file":
            self._handle_file_get(parsed.query)
            return

        self._send_json(404, {"success": False, "message": f"Not found: {path}"})

    def _handle_file_get(self, query_string):
        """
        Read one file's contents for the Review or Code Review step --
        either an extracted (pre-conversion) .sql object, or a staged
        (post-AI, pre-approval) .py review file. Restricted to paths
        under a root registered by a completed /api/extract or
        /api/convert call -- see ALLOWED_FILE_ROOTS.
        """
        params = parse_qs(query_string)
        file_path = (params.get("path") or [""])[0]

        if not file_path:
            self._send_json(400, {"success": False, "message": "Missing 'path' query parameter."})
            return
        if not file_path.lower().endswith((".sql", ".py")):
            self._send_json(400, {"success": False, "message": "Only .sql or .py files can be opened."})
            return
        if not _path_is_allowed(file_path):
            self._send_json(403, {"success": False, "message": "That path is not available for review."})
            return
        if not os.path.isfile(file_path):
            self._send_json(404, {"success": False, "message": "File not found."})
            return

        try:
            with open(file_path, "r", encoding="utf-8", errors="replace") as f:
                content = f.read()
        except OSError as exc:
            self._send_json(500, {"success": False, "message": f"Could not read file: {exc}"})
            return

        self._send_json(200, {"success": True, "path": file_path, "content": content})

    def _read_json_body(self):
        length = int(self.headers.get("Content-Length", 0))
        raw_body = self.rfile.read(length) if length > 0 else b"{}"
        return json.loads(raw_body.decode("utf-8") or "{}")

    # ---- POST ----

    def do_POST(self):
        path = urlparse(self.path).path

        if path == "/api/clone":
            self._handle_clone_post()
        elif path == "/api/extract":
            self._handle_extract_post()
        elif path == "/api/convert":
            self._handle_convert_post()
        elif path == "/api/review/approve":
            self._handle_review_approve_post()
        elif path == "/api/review/reject":
            self._handle_review_reject_post()
        elif path == "/api/file":
            self._handle_file_post()
        else:
            self._send_json(404, {"success": False, "message": f"Not found: {path}"})

    def _handle_clone_post(self):
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        repo_url = (data.get("repo_url") or "").strip()
        branch = (data.get("branch") or "main").strip()
        local_path = (data.get("local_path") or "").strip()
        on_exists = data.get("on_exists")  # None | "cancel" | "overwrite" | "pull"

        errors = {}
        err = validate_repo_url(repo_url)
        if err:
            errors["repo_url"] = err
        err = validate_branch(branch)
        if err:
            errors["branch"] = err
        err = validate_local_path(local_path)
        if err:
            errors["local_path"] = err
        git_err = check_git_installed()
        if git_err:
            errors["git"] = git_err

        if errors:
            self._send_json(400, {
                "success": False,
                "validation_errors": errors,
                "message": "Please fix the highlighted fields.",
            })
            return

        abs_path = os.path.abspath(local_path)
        dest_exists = (
            os.path.isdir(abs_path) and os.listdir(abs_path)
        ) or (os.path.exists(abs_path) and not os.path.isdir(abs_path))

        if dest_exists and on_exists is None:
            self._send_json(409, {
                "success": False,
                "conflict": True,
                "message": f"'{abs_path}' already exists and is not empty. "
                            "Overwrite it, pull the latest changes, or choose a different directory.",
            })
            return

        job_id = str(uuid.uuid4())
        with JOBS_LOCK:
            JOBS[job_id] = {
                "status": "running",
                "stage": "Queued",
                "percent": 0.0,
                "detail": "",
                "result": None,
                "started_at": time.time(),
            }

        def run():
            result = clone_repository(
                repo_url, branch=branch, local_path=local_path,
                job_id=job_id, on_exists=on_exists or "cancel",
            )
            with JOBS_LOCK:
                JOBS[job_id]["status"] = "done"
                JOBS[job_id]["result"] = result

        threading.Thread(target=run, daemon=True).start()
        self._send_json(202, {"success": True, "job_id": job_id})

    def _handle_extract_post(self):
        """
        Extraction step alone: split every .sql file under local_path into
        one file per SQL object, with no Azure OpenAI call and no config
        required. This is what populates the Review step -- nothing here
        ever reaches the API.
        """
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        local_path = (data.get("local_path") or "").strip()
        output_path = (data.get("output_path") or "").strip()
        if not output_path and local_path:
            output_path = os.path.abspath(local_path.rstrip("/\\")) + "_fabric"

        errors = {}
        if not local_path:
            errors["local_path"] = "Local repository path is required."
        elif not os.path.isdir(local_path):
            errors["local_path"] = f"'{local_path}' is not a directory. Clone a repository first."

        err = validate_local_path(output_path) if output_path else "Output directory is required."
        if err:
            errors["output_path"] = err

        if errors:
            self._send_json(400, {
                "success": False,
                "validation_errors": errors,
                "message": "Please fix the highlighted fields.",
            })
            return

        job_id = str(uuid.uuid4())
        with JOBS_LOCK:
            JOBS[job_id] = {
                "status": "running",
                "stage": "Queued",
                "percent": 0.0,
                "detail": "",
                "result": None,
                "started_at": time.time(),
            }

        def run():
            try:
                extraction = extract_only(
                    local_path, output_path,
                    progress_cb=lambda **kw: _set_job(job_id, **kw),
                )
                _register_allowed_root(extraction["extracted_root"])
                _register_allowed_root(extraction["converted_root"])
                result = {
                    "success": True, "error": None,
                    "output_path": output_path,
                    "extracted_root": extraction["extracted_root"],
                    "converted_root": extraction["converted_root"],
                    "manifest_path": extraction["manifest_path"],
                    "message": f"Extracted {extraction['total']} SQL object(s). "
                               "Nothing has been sent to Azure OpenAI yet.",
                    "manifest": extraction["manifest"],
                }
            except Exception as exc:  # keep the server alive on any unexpected failure
                result = {"success": False, "error": "unknown", "output_path": None,
                          "message": f"Unexpected error during extraction: {exc}", "manifest": None}

            with JOBS_LOCK:
                JOBS[job_id]["status"] = "done"
                JOBS[job_id]["result"] = result

        threading.Thread(target=run, daemon=True).start()
        self._send_json(202, {"success": True, "job_id": job_id})

    def _handle_convert_post(self):
        """
        Convert a user-chosen subset of already-extracted SQL objects (or
        all of them, if convert_all is explicitly set) -- staging each
        result for human review rather than writing it straight to
        converted_root or a notebook. Nothing is sent to Azure OpenAI
        until this is called with an explicit selection; nothing reaches
        converted_root or a notebook until a separate, explicit
        /api/review/approve call for that object (see below).

        Body:
            { "manifest_path": "...", "converted_root": "...",
              "selected": ["relative/path/a.sql", ...] }   -- stage just these
          or
            { "manifest_path": "...", "converted_root": "...",
              "convert_all": true }                         -- stage everything

        Reuses convert_objects_for_review() and the same job-queue pattern
        as clone/extract.
        """
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        manifest_path = (data.get("manifest_path") or "").strip()
        converted_root = (data.get("converted_root") or "").strip()
        selected = data.get("selected")
        convert_all = bool(data.get("convert_all"))

        errors = {}
        if not manifest_path or not os.path.isfile(manifest_path):
            errors["manifest_path"] = "Run extraction first -- no manifest found for this repository."
        if not converted_root:
            errors["converted_root"] = "Missing output location for converted files."
        if not convert_all and not selected:
            errors["selected"] = "Select at least one SQL object to convert, or choose Convert All."

        azure_config, missing = get_azure_config()
        if missing:
            errors["azure_config"] = (
                "Missing Azure OpenAI configuration: " + ", ".join(missing) +
                ". Set these as environment variables, or create "
                "azure_openai_config.json (see azure_openai_config.example.json)."
            )

        if errors:
            self._send_json(400, {
                "success": False,
                "validation_errors": errors,
                "message": "Please fix the highlighted fields.",
            })
            return

        try:
            full_manifest = load_manifest(manifest_path)
        except (OSError, json.JSONDecodeError) as exc:
            self._send_json(400, {"success": False, "message": f"Could not read manifest: {exc}"})
            return

        if convert_all:
            to_stage = full_manifest
        else:
            selected_set = set(selected)
            to_stage = [m for m in full_manifest if m.get("relative_path") in selected_set]
            if not to_stage:
                self._send_json(400, {"success": False,
                                       "message": "None of the selected objects were found in the manifest."})
                return

        review_root = os.path.join(os.path.dirname(converted_root), "review")

        job_id = str(uuid.uuid4())
        with JOBS_LOCK:
            JOBS[job_id] = {
                "status": "running",
                "stage": "Queued",
                "percent": 0.0,
                "detail": "",
                "result": None,
                "started_at": time.time(),
            }

        def run():
            try:
                summary = convert_objects_for_review(
                    to_stage, review_root,
                    progress_cb=lambda **kw: _set_job(job_id, **kw),
                    config=azure_config,
                    full_manifest=full_manifest,
                )
                _register_allowed_root(review_root)

                # Merge the just-staged entries back into the full
                # manifest on disk, leaving anything not selected this
                # round exactly as it was.
                by_path = {m["relative_path"]: m for m in full_manifest}
                for entry in summary["files"]:
                    by_path[entry["relative_path"]] = entry
                merged_manifest = list(by_path.values())
                write_manifest(merged_manifest, manifest_path)

                result = {"success": True, "error": None,
                          "message": f"Staged {summary['staged']} of {summary['total']} "
                                     f"selected SQL object(s) for review ({summary['failed']} failed). "
                                     "Nothing is saved to the notebook until you approve it in Code Review.",
                          "summary": summary}
            except AzureOpenAIError as exc:
                result = {"success": False, "error": "azure_openai_error",
                          "message": str(exc), "summary": None}
            except Exception as exc:  # keep the server alive on any unexpected failure
                result = {"success": False, "error": "unknown",
                          "message": f"Unexpected error during conversion: {exc}", "summary": None}

            with JOBS_LOCK:
                JOBS[job_id]["status"] = "done"
                JOBS[job_id]["result"] = result

        threading.Thread(target=run, daemon=True).start()
        self._send_json(202, {"success": True, "job_id": job_id})

    def _handle_review_approve_post(self):
        """
        Approve one "pending_review" object: write the (possibly
        human-edited) final code to converted_root and append its
        notebook cell. Synchronous -- no Azure OpenAI call happens here,
        just file writes, so there's no job to poll.

        Body: { "manifest_path": "...", "converted_root": "...",
                 "relative_path": "...", "code": "<final code text>" }
        """
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        manifest_path = (data.get("manifest_path") or "").strip()
        converted_root = (data.get("converted_root") or "").strip()
        relative_path = (data.get("relative_path") or "").strip()
        code = data.get("code")

        if not manifest_path or not os.path.isfile(manifest_path):
            self._send_json(400, {"success": False, "message": "No manifest found for this repository."})
            return
        if not converted_root or not relative_path or code is None:
            self._send_json(400, {"success": False, "message": "Missing converted_root, relative_path, or code."})
            return

        try:
            full_manifest = load_manifest(manifest_path)
        except (OSError, json.JSONDecodeError) as exc:
            self._send_json(400, {"success": False, "message": f"Could not read manifest: {exc}"})
            return

        entry = next((m for m in full_manifest if m.get("relative_path") == relative_path), None)
        if entry is None:
            self._send_json(404, {"success": False, "message": "That object isn't in the manifest."})
            return

        notebooks_root = os.path.join(os.path.dirname(converted_root), "notebooks")
        try:
            approve_object(entry, code, converted_root, notebooks_root)
        except OSError as exc:
            self._send_json(500, {"success": False, "message": f"Could not save approved file: {exc}"})
            return

        write_manifest(full_manifest, manifest_path)
        self._send_json(200, {"success": True, "entry": entry})

    def _handle_review_reject_post(self):
        """
        Reject one "pending_review" object. Synchronous, no job to poll.

        Body: { "manifest_path": "...", "relative_path": "...", "reason": "..." (optional) }
        """
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        manifest_path = (data.get("manifest_path") or "").strip()
        relative_path = (data.get("relative_path") or "").strip()
        reason = data.get("reason")

        if not manifest_path or not os.path.isfile(manifest_path):
            self._send_json(400, {"success": False, "message": "No manifest found for this repository."})
            return
        if not relative_path:
            self._send_json(400, {"success": False, "message": "Missing relative_path."})
            return

        try:
            full_manifest = load_manifest(manifest_path)
        except (OSError, json.JSONDecodeError) as exc:
            self._send_json(400, {"success": False, "message": f"Could not read manifest: {exc}"})
            return

        entry = next((m for m in full_manifest if m.get("relative_path") == relative_path), None)
        if entry is None:
            self._send_json(404, {"success": False, "message": "That object isn't in the manifest."})
            return

        reject_object(entry, reason=reason)
        write_manifest(full_manifest, manifest_path)
        self._send_json(200, {"success": True, "entry": entry})

    def _handle_file_post(self):
        """
        Save an edit made during Review (an extracted .sql object) or
        Code Review (a staged .py review file). Restricted to the same
        ALLOWED_FILE_ROOTS as the GET endpoint.
        """
        try:
            data = self._read_json_body()
        except (ValueError, json.JSONDecodeError):
            self._send_json(400, {"success": False, "message": "Invalid JSON body."})
            return

        file_path = (data.get("path") or "").strip()
        content = data.get("content")

        if not file_path:
            self._send_json(400, {"success": False, "message": "Missing 'path'."})
            return
        if content is None:
            self._send_json(400, {"success": False, "message": "Missing 'content'."})
            return
        if not file_path.lower().endswith((".sql", ".py")):
            self._send_json(400, {"success": False, "message": "Only .sql or .py files can be edited here."})
            return
        if not _path_is_allowed(file_path):
            self._send_json(403, {"success": False, "message": "That path is not available for editing."})
            return

        try:
            os.makedirs(os.path.dirname(file_path), exist_ok=True)
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(content)
        except OSError as exc:
            self._send_json(500, {"success": False, "message": f"Could not save file: {exc}"})
            return

        self._send_json(200, {"success": True, "path": file_path})


def main():
    index_path = os.path.join(BASE_DIR, "index.html")
    if not os.path.isfile(index_path):
        print(f"WARNING: {index_path} not found.")
        print(f"Make sure index.html, style.css, and script.js sit next to "
              f"server.py (expected directory: {BASE_DIR}).")

    git_err = check_git_installed()
    if git_err:
        print(f"WARNING: {git_err}")

    httpd = ThreadingHTTPServer((HOST, PORT), CloneRequestHandler)
    print(f"Serving on http://localhost:{PORT}  (Ctrl+C to stop)")
    try:
        httpd.serve_forever()
    except KeyboardInterrupt:
        print("\nShutting down.")
        httpd.shutdown()


if __name__ == "__main__":
    main()
