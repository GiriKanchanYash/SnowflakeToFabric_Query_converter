(() => {
  // =================================================================
  // Tab navigation
  // =================================================================
  const tabButtons = document.querySelectorAll('.tab-btn');
  const pages = { clone: document.getElementById('page-clone'), review: document.getElementById('page-review'), 'code-review': document.getElementById('page-code-review') };
  const reviewTabBtn = document.getElementById('review-tab-btn');
  const codeReviewTabBtn = document.getElementById('code-review-tab-btn');

  function activateTab(name) {
    tabButtons.forEach(btn => {
      const isActive = btn.dataset.tab === name;
      btn.classList.toggle('active', isActive);
      btn.setAttribute('aria-selected', isActive ? 'true' : 'false');
    });
    Object.entries(pages).forEach(([key, el]) => { el.hidden = (key !== name); });
  }

  tabButtons.forEach(btn => {
    btn.addEventListener('click', () => {
      if (btn.disabled) return;
      activateTab(btn.dataset.tab);
    });
  });

  // =================================================================
  // Shared helpers
  // =================================================================
  function escapeHtml(str) {
    const div = document.createElement('div');
    div.textContent = str == null ? '' : String(str);
    return div.innerHTML;
  }

  async function postJson(url, payload) {
    const res = await fetch(url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload),
    });
    const data = await res.json().catch(() => ({}));
    return { status: res.status, data };
  }

  async function getJson(url) {
    const res = await fetch(url);
    const data = await res.json().catch(() => ({}));
    return { status: res.status, data };
  }

  function pollJob(statusUrl, onUpdate, onDone, onError) {
    const timer = setInterval(async () => {
      try {
        const res = await fetch(statusUrl);
        if (!res.ok) { clearInterval(timer); onError('Lost track of the job. Please try again.'); return; }
        const job = await res.json();
        onUpdate(job);
        if (job.status === 'done') { clearInterval(timer); onDone(job.result || {}); }
      } catch (err) {
        clearInterval(timer);
        onError('Lost connection while checking progress.');
      }
    }, 500);
    return timer;
  }

  // =================================================================
  // PAGE 1: Clone
  // =================================================================
  const form = document.getElementById('clone-form');
  const repoUrlInput = document.getElementById('repo_url');
  const branchInput = document.getElementById('branch');
  const localPathInput = document.getElementById('local_path');
  const cloneBtn = document.getElementById('clone-btn');

  const formCard = document.getElementById('form-card');
  const conflictPanel = document.getElementById('conflict-panel');
  const conflictMessage = document.getElementById('conflict-message');
  const progressPanel = document.getElementById('progress-panel');
  const successPanel = document.getElementById('success-panel');
  const errorPanel = document.getElementById('error-panel');

  const progressStage = document.getElementById('progress-stage');
  const progressPct = document.getElementById('progress-pct');
  const progressFill = document.getElementById('progress-fill');
  const progressDetail = document.getElementById('progress-detail');
  const graphProgressLine = document.getElementById('graph-progress-line');
  const graphDots = document.getElementById('graph-dots');

  const errorMessage = document.getElementById('error-message');
  const tryAgainBtn = document.getElementById('try-again');
  const cloneAnotherBtn = document.getElementById('clone-another');

  const extractCard = document.getElementById('extract-card');
  const extractForm = document.getElementById('extract-form');
  const outputPathInput = document.getElementById('output_path');
  const extractBtn = document.getElementById('extract-btn');
  const extractProgressPanel = document.getElementById('extract-progress-panel');
  const extractErrorPanel = document.getElementById('extract-error-panel');
  const extractProgressStage = document.getElementById('extract-progress-stage');
  const extractProgressPct = document.getElementById('extract-progress-pct');
  const extractProgressFill = document.getElementById('extract-progress-fill');
  const extractProgressDetail = document.getElementById('extract-progress-detail');
  const extractErrorMessage = document.getElementById('extract-error-message');
  const extractTryAgainBtn = document.getElementById('extract-try-again');

  let dotsPlaced = 0;
  const GRAPH_X0 = 8;
  const GRAPH_X1 = 312;

  const CLONE_GROUP = [formCard, conflictPanel, progressPanel, successPanel, extractCard, extractProgressPanel, extractErrorPanel, errorPanel];
  function showOnly(el) { CLONE_GROUP.forEach(p => { p.hidden = (p !== el); }); }

  // ---- field validation ----
  const REPO_URL_RE = /^(https?|git|ssh):\/\/[^\s]+$|^[\w.-]+@[\w.-]+:[\w./-]+(\.git)?$/;
  const BRANCH_RE = /^[A-Za-z0-9._\-/]+$/;

  function setFieldError(input, hintEl, message) {
    if (message) {
      input.classList.add('invalid');
      hintEl.textContent = message;
      hintEl.classList.add('error');
    } else {
      input.classList.remove('invalid');
      hintEl.classList.remove('error');
      hintEl.textContent = hintEl.dataset.defaultText;
    }
  }

  [ ['repo_url-hint', 'HTTPS or SSH URL to a public repository.'],
    ['branch-hint', 'Defaults to main if left blank.'],
    ['local_path-hint', 'Where the repository will be checked out.'],
    ['output_path-hint', 'Extracted objects, and later the converted SQL, are written here.'],
  ].forEach(([id, text]) => { document.getElementById(id).dataset.defaultText = text; });

  function validateCloneForm() {
    let ok = true;
    const url = repoUrlInput.value.trim();
    const branch = branchInput.value.trim();
    const path = localPathInput.value.trim();

    if (!url) {
      setFieldError(repoUrlInput, document.getElementById('repo_url-hint'), 'Repository URL is required.');
      ok = false;
    } else if (!REPO_URL_RE.test(url)) {
      setFieldError(repoUrlInput, document.getElementById('repo_url-hint'), "That doesn't look like a valid Git URL.");
      ok = false;
    } else {
      setFieldError(repoUrlInput, document.getElementById('repo_url-hint'), null);
    }

    if (branch && !BRANCH_RE.test(branch)) {
      setFieldError(branchInput, document.getElementById('branch-hint'), 'Branch name has invalid characters.');
      ok = false;
    } else {
      setFieldError(branchInput, document.getElementById('branch-hint'), null);
    }

    if (!path) {
      setFieldError(localPathInput, document.getElementById('local_path-hint'), 'Local clone directory is required.');
      ok = false;
    } else {
      setFieldError(localPathInput, document.getElementById('local_path-hint'), null);
    }

    return ok;
  }

  function resetGraph() {
    graphDots.innerHTML = '';
    dotsPlaced = 0;
    graphProgressLine.setAttribute('x2', GRAPH_X0);
  }

  function updateGraph(percent) {
    const pct = percent === null || percent === undefined ? null : Math.max(0, Math.min(100, percent));
    if (pct === null) { progressFill.classList.add('indeterminate'); return; }
    progressFill.classList.remove('indeterminate');
    const x = GRAPH_X0 + (GRAPH_X1 - GRAPH_X0) * (pct / 100);
    graphProgressLine.setAttribute('x2', x.toFixed(1));
    const targetDots = Math.floor(pct / 20);
    while (dotsPlaced < targetDots) {
      dotsPlaced += 1;
      const dx = GRAPH_X0 + (GRAPH_X1 - GRAPH_X0) * (dotsPlaced * 20 / 100);
      const circle = document.createElementNS('http://www.w3.org/2000/svg', 'circle');
      circle.setAttribute('cx', dx.toFixed(1));
      circle.setAttribute('cy', '32');
      circle.setAttribute('r', '4');
      circle.setAttribute('fill', 'var(--accent)');
      graphDots.appendChild(circle);
    }
  }

  function renderProgress() {
    resetGraph();
    progressStage.textContent = 'Starting clone…';
    progressPct.textContent = '';
    progressFill.style.width = '0%';
    progressFill.classList.remove('indeterminate');
    progressDetail.textContent = '';
    showOnly(progressPanel);
  }

  function renderConflict(message) {
    conflictMessage.textContent = message;
    showOnly(conflictPanel);
  }

  function renderCloneSuccess(result) {
    document.getElementById('res-name').textContent = result.repo_name || '—';
    document.getElementById('res-branch').textContent = result.branch || '—';
    document.getElementById('res-path').textContent = result.local_path || '—';
    document.getElementById('res-status').textContent = 'Cloned successfully';
    showOnly(successPanel);

    if (result.local_path) {
      outputPathInput.value = `${result.local_path.replace(/[/\\]+$/, '')}_fabric`;
    }
    extractCard.hidden = false;
    lastLocalPath = result.local_path;
  }

  function renderCloneError(message) {
    errorMessage.textContent = message;
    showOnly(errorPanel);
    cloneBtn.disabled = false;
  }

  async function startClone(onExists) {
    cloneBtn.disabled = true;
    renderProgress();
    try {
      const payload = {
        repo_url: repoUrlInput.value.trim(),
        branch: branchInput.value.trim() || 'main',
        local_path: localPathInput.value.trim(),
      };
      if (onExists) payload.on_exists = onExists;
      const { status, data } = await postJson('/api/clone', payload);

      if (status === 202 && data.job_id) {
        pollJob(`/api/clone/status/${data.job_id}`,
          (job) => {
            progressStage.textContent = job.stage || 'Working…';
            progressDetail.textContent = job.detail || '';
            if (typeof job.percent === 'number') {
              progressPct.textContent = `${job.percent}%`;
              progressFill.style.width = `${job.percent}%`;
              updateGraph(job.percent);
            } else {
              progressPct.textContent = '';
              updateGraph(null);
            }
          },
          (result) => {
            if (result.success) renderCloneSuccess(result);
            else if (result.error === 'exists') renderConflict(result.message);
            else renderCloneError(result.message || 'The clone failed for an unknown reason.');
          },
          (msg) => renderCloneError(msg)
        );
        return;
      }
      if (status === 409 && data.conflict) { renderConflict(data.message); return; }
      if (status === 400 && data.validation_errors) {
        const errs = data.validation_errors;
        if (errs.repo_url) setFieldError(repoUrlInput, document.getElementById('repo_url-hint'), errs.repo_url);
        if (errs.branch) setFieldError(branchInput, document.getElementById('branch-hint'), errs.branch);
        if (errs.local_path) setFieldError(localPathInput, document.getElementById('local_path-hint'), errs.local_path);
        if (errs.git) { renderCloneError(errs.git); return; }
        showOnly(formCard);
        cloneBtn.disabled = false;
        return;
      }
      renderCloneError(data.message || 'Unable to start the clone. Please try again.');
    } catch (err) {
      renderCloneError('Could not reach the server. Check that the app is running and try again.');
    }
  }

  form.addEventListener('submit', (e) => {
    e.preventDefault();
    if (!validateCloneForm()) return;
    startClone(null);
  });

  conflictPanel.addEventListener('click', (e) => {
    const btn = e.target.closest('button[data-choice]');
    if (!btn) return;
    const choice = btn.dataset.choice;
    if (choice === 'cancel') { showOnly(formCard); cloneBtn.disabled = false; localPathInput.focus(); return; }
    startClone(choice);
  });

  tryAgainBtn.addEventListener('click', () => { showOnly(formCard); cloneBtn.disabled = false; });

  cloneAnotherBtn.addEventListener('click', () => {
    form.reset();
    extractCard.hidden = true;
    showOnly(formCard);
    cloneBtn.disabled = false;
    repoUrlInput.focus();
  });

  [repoUrlInput, branchInput, localPathInput].forEach(input => {
    input.addEventListener('input', () => {
      const hint = document.getElementById(`${input.id}-hint`);
      if (input.classList.contains('invalid')) setFieldError(input, hint, null);
    });
  });

  // =================================================================
  // Extraction (Clone page -> triggers switch to Review tab)
  // =================================================================
  let lastLocalPath = '';

  function renderExtractProgress() {
    extractProgressStage.textContent = 'Starting…';
    extractProgressPct.textContent = '';
    extractProgressFill.style.width = '0%';
    extractProgressFill.classList.remove('indeterminate');
    extractProgressDetail.textContent = '';
    showOnly(extractProgressPanel);
  }

  function renderExtractError(message) {
    extractErrorMessage.textContent = message;
    showOnly(extractErrorPanel);
    extractBtn.disabled = false;
  }

  extractForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    if (!outputPathInput.value.trim()) {
      const hint = document.getElementById('output_path-hint');
      outputPathInput.classList.add('invalid');
      hint.textContent = 'Output directory is required.';
      hint.classList.add('error');
      return;
    }
    extractBtn.disabled = true;
    renderExtractProgress();
    try {
      const payload = { local_path: lastLocalPath, output_path: outputPathInput.value.trim() };
      const { status, data } = await postJson('/api/extract', payload);

      if (status === 202 && data.job_id) {
        pollJob(`/api/extract/status/${data.job_id}`,
          (job) => {
            extractProgressStage.textContent = job.stage || 'Working…';
            extractProgressDetail.textContent = job.detail || '';
            if (typeof job.percent === 'number') {
              extractProgressPct.textContent = `${job.percent}%`;
              extractProgressFill.style.width = `${job.percent}%`;
              extractProgressFill.classList.remove('indeterminate');
            } else {
              extractProgressPct.textContent = '';
              extractProgressFill.classList.add('indeterminate');
            }
          },
          (result) => {
            if (result.success) {
              extractBtn.disabled = false;
              enterReviewStage(result);
            } else {
              renderExtractError(result.message || 'Extraction failed for an unknown reason.');
            }
          },
          (msg) => renderExtractError(msg)
        );
        return;
      }
      if (status === 400 && data.validation_errors) {
        const errs = data.validation_errors;
        if (errs.local_path) { renderExtractError(errs.local_path); return; }
        if (errs.output_path) {
          outputPathInput.classList.add('invalid');
          const hint = document.getElementById('output_path-hint');
          hint.textContent = errs.output_path;
          hint.classList.add('error');
          extractBtn.disabled = false;
          return;
        }
        renderExtractError(data.message || 'Please fix the highlighted fields.');
        return;
      }
      renderExtractError(data.message || 'Unable to start extraction. Please try again.');
    } catch (err) {
      renderExtractError('Could not reach the server. Check that the app is running and try again.');
    }
  });

  extractTryAgainBtn.addEventListener('click', () => { showOnly(extractCard); extractBtn.disabled = false; });

  outputPathInput.addEventListener('input', () => {
    const hint = document.getElementById('output_path-hint');
    if (outputPathInput.classList.contains('invalid')) {
      outputPathInput.classList.remove('invalid');
      hint.classList.remove('error');
      hint.textContent = hint.dataset.defaultText;
    }
  });

  // =================================================================
  // PAGE 2: Review & Convert
  // =================================================================
  const reviewSummary = document.getElementById('review-summary');
  const reviewSearch = document.getElementById('review-search');
  const reviewLayerFilters = document.getElementById('review-layer-filters');
  const reviewList = document.getElementById('review-list');
  const reviewSelectAllBtn = document.getElementById('review-select-all');
  const reviewSelectNoneBtn = document.getElementById('review-select-none');
  const reviewSelectedCount = document.getElementById('review-selected-count');
  const reviewActionsCount = document.getElementById('review-actions-count');
  const reviewConvertSelectedBtn = document.getElementById('review-convert-selected');
  const reviewConvertAllBtn = document.getElementById('review-convert-all');

  const reviewEditorFilename = document.getElementById('review-editor-filename');
  const reviewEditorStatus = document.getElementById('review-editor-status');
  const reviewEditorTextarea = document.getElementById('review-editor-textarea');
  const reviewEditorSaveBtn = document.getElementById('review-editor-save');

  const reviewBrowser = document.getElementById('review-browser');
  const convertProgressPanel = document.getElementById('convert-progress-panel');
  const convertResultPanel = document.getElementById('convert-result-panel');
  const convertErrorPanel = document.getElementById('convert-error-panel');
  const convertProgressStage = document.getElementById('convert-progress-stage');
  const convertProgressPct = document.getElementById('convert-progress-pct');
  const convertProgressFill = document.getElementById('convert-progress-fill');
  const convertProgressDetail = document.getElementById('convert-progress-detail');
  const convertErrorMessage = document.getElementById('convert-error-message');

  let manifest = [];        // full manifest for the current extraction
  let filteredPaths = [];   // relative_paths currently visible under the search filter
  let selectedPaths = new Set();
  let activeRelativePath = null;
  let extractionInfo = null; // { extracted_root, converted_root, manifest_path, output_path }
  let activeLayerFilter = 'all';

  const REVIEW_GROUP = [reviewBrowser, convertProgressPanel, convertResultPanel, convertErrorPanel];
  function showReviewOnly(el) { REVIEW_GROUP.forEach(p => { p.hidden = (p !== el); }); }

  function enterReviewStage(extractResult) {
    manifest = extractResult.manifest || [];
    extractionInfo = {
      extracted_root: extractResult.extracted_root,
      converted_root: extractResult.converted_root,
      manifest_path: extractResult.manifest_path,
      output_path: extractResult.output_path,
    };
    selectedPaths = new Set();
    activeRelativePath = null;
    activeLayerFilter = 'all';

    reviewTabBtn.disabled = false;
    activateTab('review');
    showReviewOnly(reviewBrowser);
    reviewSearch.value = '';
    renderLayerChips();
    renderReviewList();
    updateSelectionUI();
    resetEditor();
  }

  function renderLayerChips() {
    const counts = { all: manifest.length, bronze: 0, silver: 0, gold: 0, unclassified: 0 };
    manifest.forEach(m => {
      const layer = m.layer || 'unclassified';
      counts[layer] = (counts[layer] || 0) + 1;
    });
    reviewLayerFilters.querySelectorAll('.layer-chip').forEach(chip => {
      const layer = chip.dataset.layer;
      const count = counts[layer] || 0;
      chip.textContent = `${chip.dataset.layer === 'all' ? 'All' : chip.dataset.layer[0].toUpperCase() + chip.dataset.layer.slice(1)} (${count})`;
      chip.classList.toggle('active', layer === activeLayerFilter);
      chip.hidden = (layer !== 'all' && count === 0);
    });
  }

  reviewLayerFilters.addEventListener('click', (e) => {
    const chip = e.target.closest('.layer-chip');
    if (!chip) return;
    activeLayerFilter = chip.dataset.layer;
    renderLayerChips();
    renderReviewList();
  });

  function statusPillClass(status) {
    if (status === 'converted') return 'status-converted';
    if (status === 'failed') return 'status-failed';
    return 'status-pending';
  }

  function matchesSearch(entry, query) {
    if (!query) return true;
    const haystack = [
      entry.object_name, entry.filename, entry.source_file, entry.object_type, entry.layer,
    ].filter(Boolean).join(' ').toLowerCase();
    return haystack.includes(query);
  }

  function matchesLayer(entry) {
    if (activeLayerFilter === 'all') return true;
    return (entry.layer || 'unclassified') === activeLayerFilter;
  }

  function renderReviewList() {
    const query = reviewSearch.value.trim().toLowerCase();
    const visible = manifest.filter(m => matchesSearch(m, query) && matchesLayer(m));
    filteredPaths = visible.map(m => m.relative_path);

    reviewSummary.textContent = `${manifest.length} object${manifest.length === 1 ? '' : 's'} extracted` +
      (query || activeLayerFilter !== 'all' ? ` · ${visible.length} shown` : '');

    reviewList.innerHTML = '';
    visible.forEach(entry => {
      const li = document.createElement('li');
      li.className = 'review-row' + (entry.relative_path === activeRelativePath ? ' active' : '');
      li.dataset.path = entry.relative_path;

      const label = entry.object_name || entry.filename;
      const checked = selectedPaths.has(entry.relative_path) ? 'checked' : '';
      const layer = entry.layer || 'unclassified';

      li.innerHTML = `
        <input type="checkbox" data-path="${escapeHtml(entry.relative_path)}" ${checked}>
        <div class="review-row-main">
          <div class="review-row-name">${escapeHtml(label)}</div>
          <div class="review-row-meta">
            <span class="pill layer-${escapeHtml(layer)}">${escapeHtml(layer)}</span>
            ${entry.object_type ? `<span class="pill type">${escapeHtml(entry.object_type)}</span>` : ''}
            <span class="pill ${statusPillClass(entry.status)}">${escapeHtml(entry.status || 'pending')}</span>
          </div>
          <div class="review-row-source">from ${escapeHtml(entry.source_file)}</div>
        </div>`;
      reviewList.appendChild(li);
    });
  }

  function updateSelectionUI() {
    const n = selectedPaths.size;
    reviewSelectedCount.textContent = `${n} selected`;
    reviewActionsCount.textContent = `${n} selected`;
    reviewConvertSelectedBtn.disabled = n === 0;
  }

  reviewSearch.addEventListener('input', renderReviewList);

  reviewSelectAllBtn.addEventListener('click', () => {
    filteredPaths.forEach(p => selectedPaths.add(p));
    renderReviewList();
    updateSelectionUI();
  });

  reviewSelectNoneBtn.addEventListener('click', () => {
    selectedPaths.clear();
    renderReviewList();
    updateSelectionUI();
  });

  reviewList.addEventListener('click', (e) => {
    const checkbox = e.target.closest('input[type="checkbox"]');
    if (checkbox) {
      const path = checkbox.dataset.path;
      if (checkbox.checked) selectedPaths.add(path); else selectedPaths.delete(path);
      updateSelectionUI();
      return;
    }
    const row = e.target.closest('.review-row');
    if (row) openInEditor(row.dataset.path);
  });

  // ---- Inline editor ----

  let editorDirty = false;

  function resetEditor() {
    activeRelativePath = null;
    reviewEditorFilename.textContent = 'Select an object to preview';
    reviewEditorTextarea.value = '';
    reviewEditorTextarea.disabled = true;
    reviewEditorSaveBtn.disabled = true;
    reviewEditorStatus.classList.remove('visible');
    editorDirty = false;
  }

  async function openInEditor(relativePath) {
    const entry = manifest.find(m => m.relative_path === relativePath);
    if (!entry) return;

    activeRelativePath = relativePath;
    renderReviewList();
    reviewEditorFilename.textContent = `${entry.source_file} :: ${entry.filename}`;
    reviewEditorTextarea.value = 'Loading…';
    reviewEditorTextarea.disabled = true;
    reviewEditorSaveBtn.disabled = true;
    reviewEditorStatus.classList.remove('visible');

    const { status, data } = await getJson(`/api/file?path=${encodeURIComponent(entry.extracted_path)}`);
    if (status === 200 && data.success) {
      reviewEditorTextarea.value = data.content;
      reviewEditorTextarea.disabled = false;
      reviewEditorSaveBtn.disabled = false;
      editorDirty = false;
    } else {
      reviewEditorTextarea.value = `Could not load file: ${data.message || 'unknown error'}`;
    }
  }

  reviewEditorTextarea.addEventListener('input', () => { editorDirty = true; });

  reviewEditorSaveBtn.addEventListener('click', async () => {
    if (!activeRelativePath) return;
    const entry = manifest.find(m => m.relative_path === activeRelativePath);
    if (!entry) return;

    reviewEditorSaveBtn.disabled = true;
    const { status, data } = await postJson('/api/file', {
      path: entry.extracted_path,
      content: reviewEditorTextarea.value,
    });
    reviewEditorSaveBtn.disabled = false;

    if (status === 200 && data.success) {
      editorDirty = false;
      reviewEditorStatus.textContent = 'Saved';
      reviewEditorStatus.classList.add('visible');
      setTimeout(() => reviewEditorStatus.classList.remove('visible'), 1600);
    } else {
      reviewEditorStatus.textContent = data.message || 'Save failed';
      reviewEditorStatus.classList.add('visible');
    }
  });

  // ---- Conversion (selected / all) ----

  function renderConvertProgress() {
    convertProgressStage.textContent = 'Starting…';
    convertProgressPct.textContent = '';
    convertProgressFill.style.width = '0%';
    convertProgressFill.classList.remove('indeterminate');
    convertProgressDetail.textContent = '';
    showReviewOnly(convertProgressPanel);
  }

  function renderConvertError(message) {
    convertErrorMessage.textContent = message;
    showReviewOnly(convertErrorPanel);
  }

  function renderConvertResult(result) {
    const summary = result.summary || { staged: 0, failed: 0, files: [] };
    document.getElementById('cres-converted').textContent = summary.staged;
    document.getElementById('cres-failed').textContent = summary.failed;
    document.getElementById('cres-path').textContent = extractionInfo.converted_root || '—';

    const head = document.getElementById('convert-result-head');
    const title = document.getElementById('convert-result-title');
    if (summary.failed > 0) {
      head.className = 'panel-head warn';
      title.textContent = summary.staged > 0 ? 'Staged with some failures' : 'Conversion failed for all selected objects';
    } else {
      head.className = 'panel-head ok';
      title.textContent = 'Staged for review';
    }

    const list = document.getElementById('convert-file-list');
    list.innerHTML = '';
    (summary.files || []).forEach(f => {
      const li = document.createElement('li');
      const ok = f.status === 'pending_review';
      const label = f.object_name || f.filename;
      li.innerHTML = `
        <svg class="file-status ${ok ? 'ok' : 'bad'}" viewBox="0 0 16 16" aria-hidden="true">
          ${ok
            ? '<path fill="currentColor" d="M8 16A8 8 0 1 0 8 0a8 8 0 0 0 0 16Zm3.78-9.72-4.25 4.25a.75.75 0 0 1-1.06 0L4.22 8.28a.751.751 0 0 1 1.042-1.079l.018.018L7 8.94l3.72-3.72a.751.751 0 0 1 1.079 1.042Z"></path>'
            : '<path fill="currentColor" d="M2.343 13.657A8 8 0 1 1 13.657 2.343 8 8 0 0 1 2.343 13.657ZM6.03 4.97a.75.75 0 0 0-1.06 1.06L6.94 8l-1.97 1.97a.75.75 0 1 0 1.06 1.06L8 9.06l1.97 1.97a.75.75 0 0 0 1.06-1.06L9.06 8l1.97-1.97a.75.75 0 0 0-1.06-1.06L8 6.94Z"></path>'}
        </svg>
        <div class="file-info">
          <div class="file-name">${escapeHtml(label)}</div>
          <div class="file-source">from ${escapeHtml(f.source_file)}${f.object_type ? ' · ' + escapeHtml(f.object_type) : ''} · ${escapeHtml(f.status)}</div>
          ${!ok && f.error ? `<div class="file-error">${escapeHtml(f.error)}</div>` : ''}
        </div>`;
      list.appendChild(li);
    });

    // Reflect updated statuses back into the in-memory manifest for when
    // the user returns to the review list or the code-review queue.
    (summary.files || []).forEach(updated => {
      const idx = manifest.findIndex(m => m.relative_path === updated.relative_path);
      if (idx !== -1) manifest[idx] = { ...manifest[idx], ...updated };
    });

    if (summary.staged > 0) {
      codeReviewTabBtn.disabled = false;
    }

    showReviewOnly(convertResultPanel);
  }

  async function startConversion(selected, convertAll) {
    renderConvertProgress();
    try {
      const payload = {
        manifest_path: extractionInfo.manifest_path,
        converted_root: extractionInfo.converted_root,
      };
      if (convertAll) payload.convert_all = true;
      else payload.selected = selected;

      const { status, data } = await postJson('/api/convert', payload);

      if (status === 202 && data.job_id) {
        pollJob(`/api/convert/status/${data.job_id}`,
          (job) => {
            convertProgressStage.textContent = job.stage || 'Working…';
            convertProgressDetail.textContent = job.detail || '';
            if (typeof job.percent === 'number') {
              convertProgressPct.textContent = `${job.percent}%`;
              convertProgressFill.style.width = `${job.percent}%`;
              convertProgressFill.classList.remove('indeterminate');
            } else {
              convertProgressPct.textContent = '';
              convertProgressFill.classList.add('indeterminate');
            }
          },
          (result) => {
            if (result.success) renderConvertResult(result);
            else renderConvertError(result.message || 'The conversion failed for an unknown reason.');
          },
          (msg) => renderConvertError(msg)
        );
        return;
      }
      if (status === 400 && data.validation_errors) {
        const messages = Object.values(data.validation_errors).join(' ');
        renderConvertError(messages || data.message || 'Please fix the highlighted fields.');
        return;
      }
      renderConvertError(data.message || 'Unable to start the conversion. Please try again.');
    } catch (err) {
      renderConvertError('Could not reach the server. Check that the app is running and try again.');
    }
  }

  reviewConvertSelectedBtn.addEventListener('click', () => {
    if (selectedPaths.size === 0) return;
    startConversion(Array.from(selectedPaths), false);
  });

  reviewConvertAllBtn.addEventListener('click', () => {
    startConversion(null, true);
  });

  document.getElementById('convert-back-to-review').addEventListener('click', () => {
    renderReviewList();
    showReviewOnly(reviewBrowser);
  });

  document.getElementById('convert-try-again').addEventListener('click', () => {
    showReviewOnly(reviewBrowser);
  });

  document.getElementById('convert-go-to-code-review').addEventListener('click', () => {
    activateTab('code-review');
    renderCodeReviewQueue();
  });

  // =================================================================
  // PAGE 3: Code Review
  // =================================================================
  const crSummary = document.getElementById('cr-summary');
  const crSessionCount = document.getElementById('cr-session-count');
  const crQueueList = document.getElementById('cr-queue-list');
  const crDiffHeader = document.getElementById('cr-diff-header');
  const crOriginalCode = document.getElementById('cr-original-code');
  const crEditedCode = document.getElementById('cr-edited-code');
  const crRejectReason = document.getElementById('cr-reject-reason');
  const crRejectBtn = document.getElementById('cr-reject-btn');
  const crApproveBtn = document.getElementById('cr-approve-btn');
  const crActionStatus = document.getElementById('cr-action-status');

  let crActivePath = null;
  let crApprovedCount = 0;
  let crRejectedCount = 0;

  function pendingReviewEntries() {
    return manifest.filter(m => m.status === 'pending_review');
  }

  function renderCodeReviewQueue() {
    const queue = pendingReviewEntries();
    crSummary.textContent = `${queue.length} object${queue.length === 1 ? '' : 's'} pending review`;
    crSessionCount.textContent = `${crApprovedCount} approved · ${crRejectedCount} rejected this session`;

    crQueueList.innerHTML = '';
    queue.forEach(entry => {
      const li = document.createElement('li');
      li.className = 'review-row' + (entry.relative_path === crActivePath ? ' active' : '');
      li.dataset.path = entry.relative_path;
      const label = entry.object_name || entry.filename;
      li.innerHTML = `
        <div class="review-row-main">
          <div class="review-row-name">${escapeHtml(label)}</div>
          <div class="review-row-meta">
            <span class="pill layer-${escapeHtml(entry.layer || 'unclassified')}">${escapeHtml(entry.layer || 'unclassified')}</span>
            ${entry.object_type ? `<span class="pill type">${escapeHtml(entry.object_type)}</span>` : ''}
          </div>
          <div class="review-row-source">from ${escapeHtml(entry.source_file)}</div>
        </div>`;
      crQueueList.appendChild(li);
    });

    if (queue.length === 0) {
      crActivePath = null;
      resetCrDiff();
    } else if (!queue.find(e => e.relative_path === crActivePath)) {
      // Auto-advance to the first remaining item after an approve/reject.
      openInCodeReview(queue[0].relative_path);
    }
  }

  function resetCrDiff() {
    crDiffHeader.textContent = queue_is_empty_message();
    crOriginalCode.value = '';
    crEditedCode.value = '';
    crEditedCode.disabled = true;
    crApproveBtn.disabled = true;
    crRejectBtn.disabled = true;
    crActionStatus.textContent = '';
    crActionStatus.classList.remove('error');
  }

  function queue_is_empty_message() {
    return pendingReviewEntries().length === 0
      ? 'Nothing pending review right now.'
      : 'Select an object from the queue to review';
  }

  crQueueList.addEventListener('click', (e) => {
    const row = e.target.closest('.review-row');
    if (row) openInCodeReview(row.dataset.path);
  });

  async function openInCodeReview(relativePath) {
    const entry = manifest.find(m => m.relative_path === relativePath);
    if (!entry) return;

    crActivePath = relativePath;
    renderCodeReviewQueue();
    crDiffHeader.textContent = `${entry.source_file} :: ${entry.object_name || entry.filename}`;
    crOriginalCode.value = 'Loading…';
    crEditedCode.value = 'Loading…';
    crEditedCode.disabled = true;
    crApproveBtn.disabled = true;
    crRejectBtn.disabled = true;
    crActionStatus.textContent = '';
    crActionStatus.classList.remove('error');

    const [originalRes, stagedRes] = await Promise.all([
      getJson(`/api/file?path=${encodeURIComponent(entry.extracted_path)}`),
      getJson(`/api/file?path=${encodeURIComponent(entry.review_path)}`),
    ]);

    crOriginalCode.value = (originalRes.status === 200 && originalRes.data.success)
      ? originalRes.data.content
      : `Could not load original SQL: ${originalRes.data.message || 'unknown error'}`;

    if (stagedRes.status === 200 && stagedRes.data.success) {
      crEditedCode.value = stagedRes.data.content;
      crEditedCode.disabled = false;
      crApproveBtn.disabled = false;
      crRejectBtn.disabled = false;
    } else {
      crEditedCode.value = `Could not load converted code: ${stagedRes.data.message || 'unknown error'}`;
    }
  }

  crApproveBtn.addEventListener('click', async () => {
    if (!crActivePath) return;
    const entry = manifest.find(m => m.relative_path === crActivePath);
    if (!entry) return;

    crApproveBtn.disabled = true;
    crRejectBtn.disabled = true;
    crActionStatus.classList.remove('error');
    crActionStatus.textContent = 'Saving…';

    const { status, data } = await postJson('/api/review/approve', {
      manifest_path: extractionInfo.manifest_path,
      converted_root: extractionInfo.converted_root,
      relative_path: entry.relative_path,
      code: crEditedCode.value,
    });

    if (status === 200 && data.success) {
      const idx = manifest.findIndex(m => m.relative_path === entry.relative_path);
      if (idx !== -1) manifest[idx] = { ...manifest[idx], ...data.entry };
      crApprovedCount += 1;
      crActionStatus.textContent = 'Approved and saved to the notebook.';
      renderCodeReviewQueue();
    } else {
      crActionStatus.textContent = data.message || 'Approval failed.';
      crActionStatus.classList.add('error');
      crApproveBtn.disabled = false;
      crRejectBtn.disabled = false;
    }
  });

  crRejectBtn.addEventListener('click', async () => {
    if (!crActivePath) return;
    const entry = manifest.find(m => m.relative_path === crActivePath);
    if (!entry) return;

    crApproveBtn.disabled = true;
    crRejectBtn.disabled = true;
    crActionStatus.classList.remove('error');
    crActionStatus.textContent = 'Rejecting…';

    const { status, data } = await postJson('/api/review/reject', {
      manifest_path: extractionInfo.manifest_path,
      relative_path: entry.relative_path,
      reason: crRejectReason.value.trim() || null,
    });

    if (status === 200 && data.success) {
      const idx = manifest.findIndex(m => m.relative_path === entry.relative_path);
      if (idx !== -1) manifest[idx] = { ...manifest[idx], ...data.entry };
      crRejectedCount += 1;
      crRejectReason.value = '';
      crActionStatus.textContent = 'Rejected. Nothing was saved.';
      renderCodeReviewQueue();
    } else {
      crActionStatus.textContent = data.message || 'Reject failed.';
      crActionStatus.classList.add('error');
      crApproveBtn.disabled = false;
      crRejectBtn.disabled = false;
    }
  });
})();
